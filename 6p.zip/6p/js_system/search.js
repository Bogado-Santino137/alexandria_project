// SEARCH ENGINE - Requiere: FILE_INDEX, notify

class SearchEngine {
    constructor() {
        // if (typeof FILE_INDEX === 'undefined') {
        //     console.error('❌ index.js no está cargado');
        //     return;
        // }
        
        this.elements = {
            search_input: document.getElementById('KS2'),
            search_container: document.querySelector('.search-input-box'),
            box_suggestions: document.querySelector('.container-suggestions'),
            btn_search: document.getElementById('btn-buscar')
        };
        
        this.state = {
            selected_index: -1,
            current_suggestions: [],
            original_value: '',
            is_open: false
        };
        
        this.config = {
            debounce_delay: 150,
            max_suggestions: 10,
            min_chars: 1
        };
        
        this.index = this.build_search_index();
        this.valid_paths = new Set(Object.values(FILE_INDEX));
        
        if (this.elements.search_input) {
            this.init();
        }
    }
    
    build_search_index() {
        const index = [];
        
        for (const [key, path] of Object.entries(FILE_INDEX)) {
            const category = this.extract_category(path);
            
            index.push({
                key: key.toLowerCase(),
                display_key: key,
                path: path,
                category: category,
                search_text: key.toLowerCase()
            });
        }
        
        return index;
    }
    
    extract_category(path) {
        const match = path.match(/\/([\w-]+)\//);
        if (!match) return 'General';
        
        const folder = match[1];
        const categories = {
            'tutorial_php':    'PHP',
            'tutorial_html':   'HTML',
            'tutorial_js':     'JavaScript',
            'tutorial_mysql':  'MySQL',
            'tutorial_python': 'Python',
            'tutorial_css':    'CSS',
        };
        
        return categories[folder] || folder.toUpperCase();
    }
    
    init() {
        let debounce_timer;
        this.elements.search_input.addEventListener('input', (e) => {
            clearTimeout(debounce_timer);
            debounce_timer = setTimeout(() => {
                this.handle_input(e);
            }, this.config.debounce_delay);
        });
        
        this.elements.search_input.addEventListener('keydown', (e) => {
            this.handle_keydown(e);
        });
        
        if (this.elements.btn_search) {
            this.elements.btn_search.addEventListener('click', (e) => {
                e.preventDefault();
                this.execute_search();
            });
        }
        
        this.elements.box_suggestions.addEventListener('click', (e) => {
            const li = e.target.closest('li');
            if (li && !li.classList.contains('no-results')) {
                this.select_suggestion(li);
            }
        });
        
        document.addEventListener('click', (e) => {
            if (!this.elements.search_container.contains(e.target)) {
                this.close();
            }
        });
    }
    
    handle_input(e) {
        const query = e.target.value.trim();
        this.state.original_value = query;
        this.state.selected_index = -1;
        
        if (query.length < this.config.min_chars) {
            this.close();
            return;
        }
        
        const results = this.search(query);
        this.state.current_suggestions = results;
        this.render(results);
    }
    
    search(query) {
        const lower_query = query.toLowerCase();
        
        let results = this.index.filter(item => 
            item.search_text.includes(lower_query)
        );
        
        results.sort((a, b) => {
            if (a.key === lower_query) return -1;
            if (b.key === lower_query) return 1;
            
            const a_starts = a.search_text.startsWith(lower_query);
            const b_starts = b.search_text.startsWith(lower_query);
            if (a_starts && !b_starts) return -1;
            if (!a_starts && b_starts) return 1;
            
            return a.key.length - b.key.length;
        });
        
        return results.slice(0, this.config.max_suggestions);
    }
    
    render(results) {
        if (results.length === 0) {
            this.elements.box_suggestions.innerHTML = 
                '<li class="no-results">No se encontraron resultados</li>';
            this.open();
            return;
        }
        
        const grouped = this.group_by_category(results);
        
        let html = '';
        for (const [category, items] of Object.entries(grouped)) {
            if (Object.keys(grouped).length > 1) {
                html += `<li class="suggestion-category">${category}</li>`;
            }
            
            items.forEach(item => {
                html += `
                    <li class="suggestion-item" data-key="${item.display_key}">
                        ${this.highlight_match(item.display_key, this.state.original_value)}
                    </li>
                `;
            });
        }
        
        this.elements.box_suggestions.innerHTML = html;
        this.open();
    }
    
    group_by_category(results) {
        return results.reduce((grouped, item) => {
            (grouped[item.category] ||= []).push(item);
            return grouped;
        }, {});
    }
    
    highlight_match(text, query) {
        if (!query) return text;
        
        const regex = new RegExp(`(${this.escape_regex(query)})`, 'gi');
        return text.replace(regex, '<strong>$1</strong>');
    }
    
    escape_regex(str) {
        return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    
    handle_keydown(e) {
        const { key } = e;
        
        if (key === 'Enter') {
            e.preventDefault();
            this.execute_search();
            return;
        }
        
        if (key === 'Escape') {
            this.close();
            this.elements.search_input.blur();
            return;
        }
        
        if (this.state.current_suggestions.length === 0) return;
        
        const items = this.elements.box_suggestions.querySelectorAll('.suggestion-item');
        if (items.length === 0) return;
        
        if (key === 'ArrowDown') {
            e.preventDefault();
            this.state.selected_index = 
                (this.state.selected_index + 1) % items.length;
            this.update_selection(items);
        }
        
        if (key === 'ArrowUp') {
            e.preventDefault();
            this.state.selected_index = 
                this.state.selected_index <= 0 
                    ? items.length - 1 
                    : this.state.selected_index - 1;
            this.update_selection(items);
        }
    }
    
    update_selection(items) {
        items.forEach((item, index) => {
            item.classList.toggle('selected', index === this.state.selected_index);
        });
        
        if (this.state.selected_index >= 0) {
            const selected_key = items[this.state.selected_index].dataset.key;
            this.elements.search_input.value = selected_key;
        } else {
            this.elements.search_input.value = this.state.original_value;
        }
        
        if (this.state.selected_index >= 0) {
            items[this.state.selected_index].scrollIntoView({
                block: 'nearest',
                behavior: 'smooth'
            });
        }
    }
    
    execute_search() {
        const query = this.elements.search_input.value.trim().toLowerCase();
        
        if (!query) {
            notify.warning('Por favor ingresa un término de búsqueda');
            return;
        }
        
        const result = this.index.find(item => item.key === query);
        
        if (result) {
            this.navigate(result.path);
        } else {
            const partial_match = this.state.current_suggestions[0];
            if (partial_match) {
                this.navigate(partial_match.path);
            } else {
                notify.error(`No se encontró "${query}"`);
            }
        }
    }
    
    select_suggestion(element) {
        const key = element.dataset.key;
        const result = this.index.find(item => item.display_key === key);
        
        if (result) {
            this.navigate(result.path);
        }
    }
    
    navigate(path) {
        this.close();
        
        if (!this.valid_paths.has(path)) {
            notify.error('Acceso no autorizado a este archivo');
            console.error('Intento de acceso no autorizado:', path);
            return;
        }
        
        notify.info('Cargando...', 1000);
        window.location.href = path;
    }
    
    open() {
        this.elements.search_container.classList.add('active');
        this.state.is_open = true;
    }
    
    close() {
        this.elements.search_container.classList.remove('active');
        this.state.is_open = false;
        this.state.selected_index = -1;
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.search_engine = new SearchEngine();
    });
} else {
    window.search_engine = new SearchEngine();
}