/**
 * CHATBOT IA — Logica del asistente
 * ===================================
 * Lee las variables del servidor desde window.CHATBOT
 * (inyectadas por includes/header.php)
 *
 * Ubicación: js_system/chatbot.js
 */

(function () {
    'use strict';

    // Variables inyectadas por header.php
    const PROXY_URL    = window.CHATBOT.proxyUrl;
    const CURRENT_FILE = window.CHATBOT.currentFile;
    const IA_SVG       = window.CHATBOT.iaSvg;

    // Modelo activo — se lee/guarda en localStorage
    let activeModel = localStorage.getItem('chat_model') || 'llama-3.3-70b-versatile';

    let historial = [];
    let isLoading = false;
    let cachedSystemPrompt = null;

    // ── Captura solo el texto visible del contenido principal ──
    function getVisibleContent() {
        const main = document.querySelector('.main-content');
        if (!main) return null;
        return main.innerText.trim().slice(0, 6000);
    }

    const SYSTEM_PROMPT_BASE = `Sos un asistente de programación general integrado en un sistema educativo.
Ayudás a estudiantes a entender código PHP, HTML, JavaScript y MySQL.
Respondés en castellano, de forma clara y concisa.
Cuando des ejemplos de código, usá bloques de código formateados con triple backtick y el nombre del lenguaje.`;

    function buildSystemPrompt() {
        // Cachear el prompt — se construye una sola vez por sesion
        if (cachedSystemPrompt) return cachedSystemPrompt;

        if (!CURRENT_FILE) {
            cachedSystemPrompt = SYSTEM_PROMPT_BASE + '\nSi el estudiante pregunta sobre un concepto, explicá brevemente y mostrá un ejemplo práctico.';
            return cachedSystemPrompt;
        }

        const visibleText = getVisibleContent();
        if (!visibleText) {
            cachedSystemPrompt = SYSTEM_PROMPT_BASE;
            return cachedSystemPrompt;
        }

        cachedSystemPrompt = SYSTEM_PROMPT_BASE + `

El estudiante está viendo la página: ${CURRENT_FILE}
Este es el contenido visible que tiene delante:
---
${visibleText}
---
Usá este contexto para responder sus preguntas. Respondé en base a lo que el estudiante puede ver en pantalla, pero si te
hace preguntas relacionadas con la programación igualmente dale una respuesta, recordá que sos una IA de
programación general, evitá responder temas controversiales, políticos, discriminativos y religiosos.`;

        return cachedSystemPrompt;
    }

    // ── Init ──
    document.addEventListener('DOMContentLoaded', () => {
        const sendBtn  = document.getElementById('chatSendBtn');
        const input    = document.getElementById('chatInput');
        const clearBtn = document.getElementById('chatClearBtn');
        const closeBtn = document.getElementById('chatCloseBtn');
        const modelSel = document.getElementById('chatModelSelect');

        if (!sendBtn || !input) return;

        // Restaurar modelo guardado
        if (modelSel) {
            modelSel.value = activeModel;
            modelSel.addEventListener('change', () => {
                activeModel = modelSel.value;
                localStorage.setItem('chat_model', activeModel);
            });
        }

        // Al cerrar el chat, mantener la posición de scroll de la página
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                const scrollY = window.scrollY;
                requestAnimationFrame(() => {
                    window.scrollTo(0, scrollY);
                });
            });
        }

        sendBtn.addEventListener('click', sendMessage);

        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });

        input.addEventListener('input', function () {
            this.style.height = 'auto';
            const newHeight = Math.min(this.scrollHeight, 120);
            this.style.height = newHeight + 'px';
            this.style.overflowY = this.scrollHeight > 120 ? 'auto' : 'hidden';
        });

        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                historial = [];
                cachedSystemPrompt = null;
                document.getElementById('chatMessages').innerHTML = `
                    <div class="chat-welcome">
                        <img src="${IA_SVG}" alt="IA">
                        <p>Conversación limpiada.<br>¿En qué te puedo ayudar?</p>
                    </div>`;
            });
        }
    });

    // ── Enviar mensaje ──
    async function sendMessage() {
        if (isLoading) return;

        const input   = document.getElementById('chatInput');
        const sendBtn = document.getElementById('chatSendBtn');
        const texto   = input.value.trim();
        if (!texto) return;

        appendBubble('user', escHtml(texto));
        historial.push({ role: 'user', content: texto });
        input.value = '';
        input.style.height = 'auto';

        isLoading = true;
        sendBtn.disabled = true;
        const typingId = showTyping();

        try {
            const messages = [{ role: 'system', content: buildSystemPrompt() }, ...historial];

            const res = await fetch(PROXY_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ messages, model: activeModel })
            });

            removeTyping(typingId);

            if (!res.ok) {
                const err = await res.json().catch(() => ({}));
                const msg = err.error?.message || `Error HTTP ${res.status}`;
                appendBubble('bot', `<span class="chat-error-msg">❌ ${escHtml(msg)}</span>`);
                historial.pop();
                return;
            }

            const data      = await res.json();
            const respuesta = data.choices[0].message.content;
            historial.push({ role: 'assistant', content: respuesta });
            appendBubble('bot', formatResponse(respuesta));

        } catch (err) {
            removeTyping(typingId);
            appendBubble('bot', `<span class="chat-error-msg">❌ Error de conexión: ${escHtml(err.message)}</span>`);
            historial.pop();
        } finally {
            isLoading = false;
            sendBtn.disabled = false;
        }
    }

    // ── Scroll inteligente ──
    function smartScroll() {
        const el = document.getElementById('chatMessages');
        const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 60;
        if (atBottom) el.scrollTop = el.scrollHeight;
    }

    // ── Agregar burbuja ──
    function appendBubble(role, content) {
        const el = document.getElementById('chatMessages');
        const welcome = el.querySelector('.chat-welcome');
        if (welcome) welcome.remove();

        const avatarHtml = role === 'user'
            ? '<span style="font-size:14px;">👤</span>'
            : `<img src="${IA_SVG}" alt="IA">`;

        const bubble = document.createElement('div');
        bubble.className = `chat-bubble ${role}`;

        const avatar = document.createElement('div');
        avatar.className = 'chat-bubble-avatar';
        avatar.innerHTML = avatarHtml;

        const bubbleContent = document.createElement('div');
        bubbleContent.className = 'chat-bubble-content';

        const bubbleText = document.createElement('div');
        bubbleText.className = 'chat-bubble-text';

        if (content instanceof Node) {
            bubbleText.appendChild(content);
        } else {
            bubbleText.innerHTML = content;
        }

        bubbleContent.appendChild(bubbleText);
        bubble.appendChild(avatar);
        bubble.appendChild(bubbleContent);
        el.appendChild(bubble);
        smartScroll();
    }

    // ── Indicador de escritura ──
    function showTyping() {
        const el = document.getElementById('chatMessages');
        const id = 'typing-' + Date.now();
        const d  = document.createElement('div');
        d.id = id;
        d.className = 'chat-bubble bot';
        d.innerHTML = `
            <div class="chat-bubble-avatar">
                <img src="${IA_SVG}" alt="IA">
            </div>
            <div class="chat-bubble-content">
                <div class="chat-bubble-text" style="padding:8px 14px;">
                    <div class="chat-typing"><span></span><span></span><span></span></div>
                </div>
            </div>`;
        el.appendChild(d);
        smartScroll();
        return id;
    }

    function removeTyping(id) {
        const el = document.getElementById(id);
        if (el) el.remove();
    }

    // ── Renderizar Markdown con marked.js ──
    function formatResponse(text) {
        const wrapper = document.createElement('div');

        if (typeof marked === 'undefined') {
            wrapper.textContent = text;
            return wrapper;
        }

        marked.setOptions({ breaks: true, gfm: true });
        wrapper.innerHTML = marked.parse(text);

        wrapper.querySelectorAll('pre').forEach(pre => {
            const code = pre.querySelector('code');
            if (!code) return;

            const cls  = code.className || '';
            const lang = cls.replace('language-', '').toUpperCase() || 'CODE';

            const header = document.createElement('div');
            header.className = 'chat-code-header';

            const label = document.createElement('span');
            label.className = 'chat-code-label';
            label.textContent = lang;

            const btn = document.createElement('button');
            btn.className = 'chat-copy-btn';
            btn.title = 'Copiar código';
            btn.innerHTML = `
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                </svg>
                Copiar`;

            btn.addEventListener('click', () => copyCode(code.innerText, btn));

            header.appendChild(label);
            header.appendChild(btn);

            const block = document.createElement('div');
            block.className = 'chat-code-block';
            pre.parentNode.insertBefore(block, pre);
            block.appendChild(header);
            block.appendChild(pre);
        });

        return wrapper;
    }

    // ── Copiar con feedback visual ──
    async function copyCode(text, btn) {
        try {
            await navigator.clipboard.writeText(text);
            btn.innerHTML = `
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                </svg>
                ¡Copiado!`;
            btn.classList.add('copied');
            setTimeout(() => {
                btn.innerHTML = `
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/>
                    </svg>
                    Copiar`;
                btn.classList.remove('copied');
            }, 2000);
        } catch {
            btn.textContent = '✗ Error';
        }
    }

    // ── Escapar HTML ──
    function escHtml(str) {
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

})();