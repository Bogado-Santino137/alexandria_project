(function() {

    // ── Limpiar hash #menu al cargar ──
    if (window.location.hash === '#menu') {
        history.replaceState(null, '', window.location.pathname + window.location.search);
    }

    // ── Hamburguesa / Sidebar mobile ──
    const btnHamburger = document.getElementById('btnHamburger');
    const aside        = document.querySelector('aside');
    const overlay      = document.getElementById('sidebarOverlay');

    if (btnHamburger && aside && overlay) {
        function openSidebar() {
            aside.classList.add('open');
            overlay.classList.add('active');
            btnHamburger.classList.add('open');
            document.body.style.overflow = 'hidden';
            const searchBox = document.querySelector('.search-input-box');
            if (searchBox) searchBox.classList.remove('active');
        }

        function closeSidebar() {
            aside.classList.remove('open');
            overlay.classList.remove('active');
            btnHamburger.classList.remove('open');
            document.body.style.overflow = '';
        }

        btnHamburger.addEventListener('click', () => aside.classList.contains('open') ? closeSidebar() : openSidebar());
        overlay.addEventListener('click', closeSidebar);
        aside.addEventListener('click', (e) => { if (e.target.closest('a')) closeSidebar(); });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeSidebar(); });
    }

    // ── Share por sección ──
    // Genera un ID limpio a partir del texto del h2
    function slugify(text) {
        return text
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '') // quitar tildes
            .replace(/[^a-z0-9\s-]/g, '')
            .trim()
            .replace(/\s+/g, '-');
    }

    // Copia la URL al portapapeles con fallback
    function copyToClipboard(url, btn) {
        const isMobile = /Mobi|Android/i.test(navigator.userAgent);

        const doShare = async () => {
            if (isMobile && navigator.share) {
                try {
                    await navigator.share({ title: document.title, url });
                    return;
                } catch (e) {
                    if (e.name === 'AbortError') return;
                }
            }

            try {
                await navigator.clipboard.writeText(url);
            } catch {
                // Fallback sin foco
                const el = document.createElement('textarea');
                el.value = url;
                el.style.cssText = 'position:fixed;opacity:0';
                document.body.appendChild(el);
                el.focus();
                el.select();
                document.execCommand('copy');
                document.body.removeChild(el);
            }

            // Feedback visual en el botón
            btn.classList.add('copied');
            btn.querySelector('span').textContent = '¡Copiado!';
            
            setTimeout(() => {
                btn.classList.remove('copied');
                btn.querySelector('span').textContent = '';
            }, 2000);

            if (typeof notify !== 'undefined') {
                notify.success('Link copiado al portapapeles');
            }
        };

        doShare();
    }

    // SVG del ícono share
    const shareSVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="18" cy="5" r="3"/>
        <circle cx="6" cy="12" r="3"/>
        <circle cx="18" cy="19" r="3"/>
        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
    </svg>`;

    // Agregar botón share a cada .tutorial-section
    document.querySelectorAll('.tutorial-section').forEach((section) => {
        const h2 = section.querySelector('h2');
        if (!h2) return;

        // Generar y asignar ID al section si no tiene uno
        if (!section.id) {
            section.id = slugify(h2.textContent);
        }

        // Crear botón
        const btn = document.createElement('button');
        btn.className = 'section-share-btn';
        btn.title = 'Compartir esta sección';
        btn.innerHTML = `${shareSVG}<span></span>`;

        btn.addEventListener('click', () => {
            const url = `${location.origin}${location.pathname}#${section.id}`;
            copyToClipboard(url, btn);
        });

        section.appendChild(btn);
    });

    // ── Scroll al anchor al cargar la página ──
    // Necesario porque el header fijo puede tapar el elemento
    if (location.hash) {
        const target = document.querySelector(location.hash);
        if (target) {
            setTimeout(() => {
                const offset = 70; // altura del header fijo
                const top = target.getBoundingClientRect().top + window.scrollY - offset;
                window.scrollTo({ top, behavior: 'smooth' });
            }, 100);
        }
    }

})();