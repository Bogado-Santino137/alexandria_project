// ROUTES - Índice de rutas del proyecto

const WEB_ROOT = (function() {
    const path = window.location.pathname;
    const parts = path.split('/').filter(p => p);

    const exerciseFolders = [
        'editor', 'editor_db', 'js_system', 'css_system', 'ejemplos',
        'tutorial_php', 'tutorial_html', 'tutorial_js',
        'tutorial_mysql', 'tutorial_python', 'tutorial_css'
    ];

    // Si el último segmento es una carpeta de ejercicios, subimos un nivel
    const lastPart = parts[parts.length - 1];
    if (exerciseFolders.includes(lastPart)) {
        return '/' + parts.slice(0, -1).join('/');
    }

    // Si el penúltimo segmento es una carpeta de ejercicios, subimos dos niveles
    const secondLast = parts[parts.length - 2];
    if (exerciseFolders.includes(secondLast)) {
        return '/' + parts.slice(0, -2).join('/');
    }

    // Estamos en la raíz — quitamos solo el archivo .php final
    return '/' + parts.slice(0, -1).join('/');
})();

function buildPath(relativePath) {
    return WEB_ROOT + '/' + relativePath.replace(/^\/+/, '');
}

// --- RUTAS ÚNICAS ---
const PATHS = {
    // PHP Básico
    php_01: buildPath('tutorial_php/01_variables.php'),
    php_02: buildPath('tutorial_php/02_strings.php'),
    
    // HTML
    html_01: buildPath('tutorial_html/01_basico.php'),
    
    // JavaScript
    js_01: buildPath('tutorial_js/01_variables.php'),
    
    // MySQL
    mysql_01: buildPath('tutorial_mysql/01_basico.php'),
    
    // python
    py_01: buildPath('tutorial_python/01_variables.php'),

    // CSS
    css_01: buildPath('tutorial_css/01_selectores.php'),
    css_02: buildPath('tutorial_css/02_colores.php'),
};

// --- ÍNDICE CON ALIASES ---
const FILE_INDEX = {
    // PHP Básico
    'Variables PHP': PATHS.php_01,
    'Strings PHP': PATHS.php_02,
    
    // HTML
    'HTML Básico': PATHS.html_01,
    
    // JavaScript
    'Variables JavaScript': PATHS.js_01,
    
    // MySQL
    'MySQL Básico': PATHS.mysql_01,
    
    // python
    'Variables Python': PATHS.py_01,

    // CSS
    'Selectores CSS':   PATHS.css_01,
    'Colores CSS':      PATHS.css_02,
};