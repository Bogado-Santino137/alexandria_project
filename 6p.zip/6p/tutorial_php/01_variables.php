<?php
/**
 * Tutorial: Variables en PHP
 */

$pageTitle = "Variables en PHP - Tutorial Interactivo";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="layout-container">
    <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

    <main class="main-content">
<div class="tutorial-container" style="--lang-color: #777BB4">

    <div class="tutorial-intro php">
        <h1>Variables en PHP</h1>
        <p>Aprendé a declarar, usar y manipular variables en PHP. Las variables son la base de la programación.</p>
    </div>

    <div class="tutorial-section">
        <h2>¿Qué son las Variables?</h2>
        <p>
            Las variables son <strong>contenedores que almacenan datos</strong> en la memoria de tu programa.
            En PHP, todas las variables comienzan con el símbolo <code>$</code>.
        </p>
        <pre><code class="language-php">$nombre   = "Juan";
$edad     = 25;
$precio   = 19.99;
$esActivo = true;</code></pre>
        <div class="note-box info">
            <strong>Importante</strong>
            <p>En PHP no necesitás declarar el tipo de variable. PHP lo detecta automáticamente.</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Sintaxis Básica</h2>
        <p>Para crear una variable en PHP:</p>
        <pre><code class="language-php">$nombreVariable = valor;</code></pre>
        <p><strong>Reglas:</strong></p>
        <ul>
            <li>Debe comenzar con <code>$</code></li>
            <li>El nombre debe empezar con letra o guión bajo <code>_</code></li>
            <li>Puede contener letras, números y guiones bajos</li>
            <li>Es case-sensitive: <code>$nombre</code> es diferente a <code>$Nombre</code></li>
        </ul>
        <pre><code class="language-php">// Correcto
$nombre       = "Ana";
$edad_usuario = 30;
$_total       = 100;

// Incorrecto
$2nombre      = "Error";  // No puede empezar con número
$precio-total = 50;       // No puede tener guiones</code></pre>
        <a href="../editor/index.php?ejemplo=php_01_variables_01" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 1: Variables básicas
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Tipos de Datos</h2>
        <p>PHP soporta varios tipos de datos básicos:</p>
        <div class="card-grid">
            <div class="info-card">
                <h4>String (Texto)</h4>
                <code>$nombre = "Juan";</code>
            </div>
            <div class="info-card">
                <h4>Integer (Entero)</h4>
                <code>$edad = 25;</code>
            </div>
            <div class="info-card">
                <h4>Float (Decimal)</h4>
                <code>$precio = 19.99;</code>
            </div>
            <div class="info-card">
                <h4>Boolean</h4>
                <code>$activo = true;</code>
            </div>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Operaciones Básicas</h2>

        <h3>Concatenación de texto</h3>
        <pre><code class="language-php">$nombre         = "Juan";
$apellido       = "Pérez";
$nombreCompleto = $nombre . " " . $apellido;
echo $nombreCompleto;  // Juan Pérez</code></pre>
        <a href="../editor/index.php?ejemplo=php_01_variables_02" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 2: Concatenación
        </a>

        <h3>Aritmética</h3>
        <pre><code class="language-php">$a = 10;
$b = 5;
$suma           = $a + $b;  // 15
$resta          = $a - $b;  // 5
$multiplicacion = $a * $b;  // 50
$division       = $a / $b;  // 2</code></pre>
        <a href="../editor/index.php?ejemplo=php_01_variables_03" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 3: Aritmética
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Ejemplo Completo</h2>
        <p>Calculando el precio final de una compra:</p>
        <pre><code class="language-php">&lt;?php
$producto  = "Laptop";
$precio    = 899.99;
$descuento = 0.15;
$cantidad  = 2;

$precioConDescuento = $precio - ($precio * $descuento);
$total = $precioConDescuento * $cantidad;

echo "Producto: $producto\n";
echo "Precio original: $$precio\n";
echo "Descuento: " . ($descuento * 100) . "%\n";
echo "Precio con descuento: $$precioConDescuento\n";
echo "Total a pagar: $$total";
?&gt;</code></pre>
        <a href="../editor/index.php?ejemplo=php_01_variables_04" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 4: Caso completo
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Buenas Prácticas</h2>
        <ul>
            <li><strong>Nombres descriptivos:</strong> <code>$precioTotal</code> en vez de <code>$pt</code></li>
            <li><strong>camelCase o snake_case:</strong> <code>$nombreUsuario</code> o <code>$nombre_usuario</code> — elegí uno y sé consistente</li>
            <li><strong>Inicializá siempre:</strong> dale un valor antes de usar la variable</li>
            <li><strong>Evitá nombres genéricos:</strong> <code>$datos</code> no dice nada, <code>$datosUsuario</code> sí</li>
        </ul>
    </div>

</div>
    </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>