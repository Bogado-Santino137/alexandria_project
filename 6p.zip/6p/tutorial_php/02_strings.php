<?php
/**
 * Tutorial: Strings en PHP
 */

$pageTitle = "Strings en PHP - Tutorial Interactivo";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="layout-container">
    <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

    <main class="main-content">
<div class="tutorial-container" style="--lang-color: #777BB4">

    <div class="tutorial-intro php">
        <h1>Strings en PHP</h1>
        <p>Aprendé a trabajar con cadenas de texto: crear, manipular y usar las funciones más útiles.</p>
    </div>

    <div class="tutorial-section">
        <h2>¿Qué es un String?</h2>
        <p>
            Un <strong>string</strong> es una secuencia de caracteres.
            En PHP podés crearlo con comillas simples o dobles.
        </p>
        <pre><code class="language-php">$texto1 = "Hola Mundo";  // Comillas dobles
$texto2 = 'Hola Mundo';  // Comillas simples</code></pre>
        <div class="note-box info">
            <strong>Diferencia clave:</strong>
            <p>Las comillas dobles permiten interpolación de variables, las simples no.</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Comillas Simples vs Dobles</h2>
        <table class="syntax-table">
            <thead>
                <tr>
                    <th>Característica</th>
                    <th>Comillas Dobles " "</th>
                    <th>Comillas Simples ' '</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Variables</strong></td>
                    <td><code>echo "Hola $nombre";</code> — interpola</td>
                    <td><code>echo 'Hola $nombre';</code> — literal</td>
                </tr>
                <tr>
                    <td><strong>Secuencias</strong></td>
                    <td><code>"\n \t \\"</code> — funciona</td>
                    <td><code>'\n \t'</code> — literal</td>
                </tr>
                <tr>
                    <td><strong>Rendimiento</strong></td>
                    <td>Más lento</td>
                    <td>Más rápido</td>
                </tr>
            </tbody>
        </table>
        <pre><code class="language-php">$nombre = "Ana";

echo "Hola, $nombre";  // Hola, Ana
echo 'Hola, $nombre';  // Hola, $nombre</code></pre>
        <a href="../editor/index.php?ejemplo=php_02_strings_01" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 1: Comillas simples vs dobles
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Concatenación de Strings</h2>
        <p>
            Para unir strings usás el operador punto <code>.</code>.
            Si querés agregar texto a una variable existente, usás <code>.=</code>.
        </p>
        <pre><code class="language-php">$nombre   = "Juan";
$apellido = "Pérez";

$nombreCompleto = $nombre . " " . $apellido;
echo $nombreCompleto;  // Juan Pérez

$saludo  = "Hola";
$saludo .= " Mundo";   // equivale a: $saludo = $saludo . " Mundo"
echo $saludo;          // Hola Mundo</code></pre>
        <a href="../editor/index.php?ejemplo=php_02_strings_02" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 2: Concatenación
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Funciones Útiles</h2>
        <p>PHP tiene funciones incorporadas para trabajar con texto:</p>
        <div class="card-grid wide">
            <div class="info-card">
                <h4>strlen()</h4>
                <code>strlen("Hola") → 4</code>
                <p>Longitud del string</p>
            </div>
            <div class="info-card">
                <h4>strtoupper()</h4>
                <code>strtoupper("hola") → "HOLA"</code>
                <p>Convertir a mayúsculas</p>
            </div>
            <div class="info-card">
                <h4>strtolower()</h4>
                <code>strtolower("HOLA") → "hola"</code>
                <p>Convertir a minúsculas</p>
            </div>
            <div class="info-card">
                <h4>trim()</h4>
                <code>trim("  texto  ") → "texto"</code>
                <p>Eliminar espacios</p>
            </div>
            <div class="info-card">
                <h4>substr()</h4>
                <code>substr("Hola", 0, 2) → "Ho"</code>
                <p>Extraer porción</p>
            </div>
            <div class="info-card">
                <h4>str_replace()</h4>
                <code>str_replace("a","o","Ana") → "Ono"</code>
                <p>Reemplazar texto</p>
            </div>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Interpolación de Variables</h2>
        <p>Con comillas dobles podés insertar variables directamente dentro del string:</p>
        <pre><code class="language-php">$nombre = "Carlos";
$edad   = 30;

echo "Me llamo $nombre";        // Me llamo Carlos
echo "Tengo {$edad} años";      // Tengo 30 años</code></pre>
        <div class="note-box tip">
            <strong>Buena práctica:</strong>
            <p>Usá llaves <code>{$variable}</code> para mayor claridad, especialmente cuando la variable está pegada a otro texto.</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Ejemplo Completo</h2>
        <p>Combinando varias funciones en un caso práctico:</p>
        <pre><code class="language-php">&lt;?php
$texto = "  PHP es GENIAL para desarrollo web  ";

$textoLimpio  = trim($texto);
$longitud     = strlen($textoLimpio);
$minusculas   = strtolower($textoLimpio);
$mayusculas   = strtoupper($textoLimpio);
$reemplazo    = str_replace("GENIAL", "excelente", $textoLimpio);
$capitalizado = ucfirst(strtolower($textoLimpio));

echo "Limpio: '$textoLimpio'\n";
echo "Longitud: $longitud caracteres\n";
echo "Minúsculas: $minusculas\n";
echo "Mayúsculas: $mayusculas\n";
echo "Reemplazo: $reemplazo\n";
echo "Capitalizado: $capitalizado\n";
?&gt;</code></pre>
        <a href="../editor/index.php?ejemplo=php_02_strings_03" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 3: Caso completo
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Tips y Buenas Prácticas</h2>
        <ul>
            <li><strong>Usá comillas simples</strong> cuando no necesités interpolación (más rápido)</li>
            <li><strong>Usá comillas dobles</strong> cuando necesités variables o secuencias especiales</li>
            <li><strong>trim()</strong> siempre antes de procesar inputs de usuarios</li>
            <li><strong>htmlspecialchars()</strong> para prevenir XSS al mostrar texto de usuarios</li>
            <li><strong>strlen()</strong> para validar longitud de contraseñas, nombres, etc.</li>
        </ul>
    </div>

</div>
    </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>