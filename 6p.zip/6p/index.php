<?php
/**
 * INDEX - Página Principal
 */

require_once __DIR__ . '/config.php';

$pageTitle = "Inicio - Sistema de Ejercicios";
require_once INCLUDES_PATH . '/header.php';
?>

<div class="layout-container">
    <?php require_once INCLUDES_PATH . '/sidebar.php'; ?>

    <main class="main-content">
        <div class="tutorial-container">

            <div class="tutorial-intro php">
                <h1>Bienvenido al Sistema de Ejercicios</h1>
                <p>Un entorno organizado para aprender y practicar PHP, HTML, JavaScript y MySQL.</p>
            </div>

            <div class="tutorial-section">
                <h2>¿Cómo usar el sistema?</h2>
                <ul>
                    <li><strong>Buscador:</strong> usá la barra superior para encontrar archivos rápidamente por nombre o contenido</li>
                    <li><strong>Menú lateral:</strong> navegá por las categorías — PHP, HTML, JavaScript, MySQL, Python</li>
                    <li><strong>Editor de código:</strong> hacé click en el botón"Editor" para probar código dentro de la página</li>
                    <li><strong>Chat IA:</strong> usá el asistente para consultar dudas sobre el código que estás viendo</li>
                </ul>
            </div>

            <div class="tutorial-section">
                <h2>Categorías disponibles</h2>
                <div class="card-grid">
                    <div class="info-card info-card--php">
                        <h4>PHP</h4>
                        <p>Variables, strings, funciones y ejercicios prácticos</p>
                    </div>
                    <div class="info-card info-card--html">
                        <h4>HTML</h4>
                        <p>Estructura, elementos, formularios y tablas</p>
                    </div>
                    <div class="info-card info-card--js">
                        <h4>JavaScript</h4>
                        <p>Interactividad, lógica y manipulación del DOM</p>
                    </div>
                    <div class="info-card info-card--mysql">
                        <h4>MySQL</h4>
                        <p>Bases de datos, consultas y conexiones</p>
                    </div>
                    <div class="info-card info-card--python">
                        <h4>Python</h4>
                        <p>Fundamentos y ejercicios de programación</p>
                    </div>
                    <div class="info-card info-card--css">
                        <h4>CSS</h4>
                        <p>Selectores, colores, tipografía y diseño visual</p>
                    </div>
                </div>
            </div>

            <div class="note-box tip">
                <strong>Consejo</strong>
                <p>Usá el buscador con palabras clave como "formulario", "variables" o "mysql". El sistema encuentra archivos incluso con búsquedas parciales.</p>
            </div>

        </div>
    </main>
</div>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>