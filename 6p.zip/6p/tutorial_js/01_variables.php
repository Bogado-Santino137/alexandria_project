<?php
/**
 * Tutorial: Variables en JavaScript
 */

$pageTitle = "Variables en JavaScript - Tutorial Interactivo";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="layout-container">
    <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

    <main class="main-content">
<div class="tutorial-container" style="--lang-color: #F7DF1E">

    <div class="tutorial-intro js">
        <h1>Variables en JavaScript</h1>
        <p>Aprendé a declarar y usar variables en JS con <code>let</code>, <code>const</code> y <code>var</code>.</p>
    </div>

    <div class="tutorial-section">
        <h2>¿Qué es una Variable?</h2>
        <p>
            Una variable es un <strong>contenedor con nombre</strong> que guarda un valor en memoria.
            En JavaScript hay tres formas de declararlas.
        </p>
        <pre><code class="language-javascript">let nombre   = "Juan";
const PI     = 3.14159;
var contador = 0;</code></pre>
        <div class="note-box info">
            <strong>Regla general</strong>
            <p>Usá <code>const</code> por defecto. Si necesitás reasignar el valor, usá <code>let</code>. Evitá <code>var</code> — es obsoleto.</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Mostrar resultados en la página</h2>
        <p>
            En PHP usás <code>echo</code> para mostrar texto. En JavaScript usás
            <code>document.getElementById()</code> para escribir en un elemento HTML de la página.
        </p>
        <pre><code class="language-javascript">// HTML: &lt;p id="resultado"&gt;&lt;/p&gt;

let nombre = "Juan";
document.getElementById("resultado").innerHTML = "Hola, " + nombre;</code></pre>
        <a href="../editor/index.php?ejemplo=js_01_variables_01" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 1: Variables básicas
        </a>
        <div class="note-box tip">
            <strong>¿Por qué no console.log?</strong>
            <p><code>console.log()</code> muestra en las DevTools del navegador — el alumno no lo ve. Con <code>getElementById</code> el resultado aparece directo en la página, igual que <code>echo</code> en PHP.</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>let, const y var</h2>
        <table class="syntax-table">
            <thead>
                <tr>
                    <th>Keyword</th>
                    <th>Se puede reasignar</th>
                    <th>Scope</th>
                    <th>Uso recomendado</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>let</code></td>
                    <td>✅ Sí</td>
                    <td>Bloque</td>
                    <td>Variables que cambian</td>
                </tr>
                <tr>
                    <td><code>const</code></td>
                    <td>❌ No</td>
                    <td>Bloque</td>
                    <td>Valores fijos</td>
                </tr>
                <tr>
                    <td><code>var</code></td>
                    <td>✅ Sí</td>
                    <td>Función</td>
                    <td>Evitar — legado</td>
                </tr>
            </tbody>
        </table>
        <pre><code class="language-javascript">let edad = 20;
edad = 21;        // ✅ OK — let se puede reasignar

const PAIS = "Argentina";
PAIS = "Brasil";  // ❌ Error — const no se puede reasignar</code></pre>
        <a href="../editor/index.php?ejemplo=js_01_variables_02" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 2: let, const y var
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Tipos de Datos</h2>
        <p>JavaScript detecta el tipo automáticamente según el valor asignado:</p>
        <div class="card-grid">
            <div class="info-card">
                <h4>String</h4>
                <code>let nombre = "Juan";</code>
            </div>
            <div class="info-card">
                <h4>Number</h4>
                <code>let edad = 25;</code>
            </div>
            <div class="info-card">
                <h4>Boolean</h4>
                <code>let activo = true;</code>
            </div>
            <div class="info-card">
                <h4>Array</h4>
                <code>let items = [1, 2, 3];</code>
            </div>
            <div class="info-card">
                <h4>Object</h4>
                <code>let user = { nombre: "Ana" };</code>
            </div>
            <div class="info-card">
                <h4>Null / Undefined</h4>
                <code>let x = null;</code>
            </div>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Operaciones Básicas</h2>

        <h3>Concatenación y template literals</h3>
        <pre><code class="language-javascript">let nombre = "Carlos";
let edad   = 30;

// Con operador + (igual que en PHP)
document.getElementById("res1").innerHTML = "Hola " + nombre + ", tenés " + edad + " años";

// Con template literal — más limpio (similar a interpolación PHP)
document.getElementById("res2").innerHTML = `Hola ${nombre}, tenés ${edad} años`;</code></pre>
        <a href="../editor/index.php?ejemplo=js_01_variables_03" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 3: Concatenación y template literals
        </a>

        <h3>Aritmética</h3>
        <pre><code class="language-javascript">let a = 10;
let b = 3;

let suma       = a + b;   // 13
let resta      = a - b;   // 7
let multi      = a * b;   // 30
let division   = a / b;   // 3.33...
let resto      = a % b;   // 1
let potencia   = a ** b;  // 1000

document.getElementById("resultado").innerHTML =
    `${a} + ${b} = ${suma} | ${a} - ${b} = ${resta} | ${a} * ${b} = ${multi}`;</code></pre>
        <a href="../editor/index.php?ejemplo=js_01_variables_04" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 4: Aritmética
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Ejemplo Completo</h2>
        <p>Calculando el precio final y mostrándolo en la página:</p>
        <pre><code class="language-javascript">const producto  = "Laptop";
const precio    = 899.99;
const descuento = 0.15;
const cantidad  = 2;

let precioConDescuento = precio - (precio * descuento);
let total              = precioConDescuento * cantidad;

document.getElementById("producto").innerHTML = producto;
document.getElementById("original").innerHTML = "$" + precio;
document.getElementById("dcto").innerHTML     = (descuento * 100) + "%";
document.getElementById("final").innerHTML    = "$" + precioConDescuento.toFixed(2);
document.getElementById("total").innerHTML    = "$" + total.toFixed(2);</code></pre>
        <a href="../editor/index.php?ejemplo=js_01_variables_05" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 5: Caso completo
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Buenas Prácticas</h2>
        <ul>
            <li><strong>Preferí <code>const</code>:</strong> si el valor no cambia, declaralo constante</li>
            <li><strong>camelCase:</strong> <code>nombreUsuario</code>, <code>precioTotal</code> — es el estándar en JS</li>
            <li><strong>Nombres descriptivos:</strong> <code>cantidadProductos</code> en vez de <code>n</code></li>
            <li><strong>Template literals:</strong> usá backticks en vez de concatenar con <code>+</code></li>
            <li><strong>Nunca <code>var</code>:</strong> tiene comportamientos raros por el hoisting — siempre <code>let</code> o <code>const</code></li>
        </ul>
    </div>

</div>
    </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>