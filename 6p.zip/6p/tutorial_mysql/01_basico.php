<?php
/**
 * Tutorial: MySQL Básico
 */

$pageTitle = "MySQL Básico - Tutorial Interactivo";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="layout-container">
    <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

    <main class="main-content">
<div class="tutorial-container" style="--lang-color: #00758F">

    <div class="tutorial-intro mysql">
        <h1>MySQL Básico</h1>
        <p>Aprendé a consultar y manipular bases de datos relacionales con MySQL, el motor de base de datos más usado del mundo y el que usa XAMPP.</p>
    </div>

    <div class="tutorial-section">
        <h2>¿Qué es MySQL?</h2>
        <p>
            <strong>MySQL</strong> es un sistema gestor de bases de datos relacionales (RDBMS).
            Organiza la información en <strong>tablas</strong> con filas y columnas.
            Para comunicarse con MySQL usamos <strong>SQL</strong> (Structured Query Language).
        </p>
        <pre><code class="language-sql">-- Consultar todos los clientes de la tienda
SELECT * FROM clientes;</code></pre>
        <div class="note-box info">
            <strong>SQL vs MySQL</strong>
            <p>SQL es el lenguaje. MySQL es el motor que lo interpreta. Es la misma diferencia que entre JavaScript (lenguaje) y el navegador (motor que lo ejecuta).</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Estructura de una Base de Datos</h2>
        <p>Una base de datos organiza la información en distintos niveles:</p>
        <div class="card-grid wide">
            <div class="info-card">
                <h4>Base de Datos</h4>
                <code>tutorial_db</code>
                <p>Contenedor principal que agrupa las tablas</p>
            </div>
            <div class="info-card">
                <h4>Tabla</h4>
                <code>clientes, productos...</code>
                <p>Organiza datos en filas y columnas</p>
            </div>
            <div class="info-card">
                <h4>Fila (Registro)</h4>
                <code>1, 'Juan Pérez', ...</code>
                <p>Un registro individual de datos</p>
            </div>
            <div class="info-card">
                <h4>Columna (Campo)</h4>
                <code>nombre, email, ciudad</code>
                <p>Un atributo específico de cada registro</p>
            </div>
        </div>

        <h3>La base de datos que usamos</h3>
        <p>En este tutorial trabajamos con <code>tutorial_db</code>, una tienda online:</p>
        <table class="syntax-table">
            <thead>
                <tr><th>Tabla</th><th>Descripción</th><th>Registros</th></tr>
            </thead>
            <tbody>
                <tr><td><code>clientes</code></td><td>Clientes de la tienda</td><td>15</td></tr>
                <tr><td><code>productos</code></td><td>Productos disponibles</td><td>29</td></tr>
                <tr><td><code>categorias</code></td><td>Categorías de productos</td><td>8</td></tr>
                <tr><td><code>ordenes</code></td><td>Órdenes de compra</td><td>25</td></tr>
                <tr><td><code>detalle_ordenes</code></td><td>Productos de cada orden</td><td>55</td></tr>
            </tbody>
        </table>

        <h3>Ejemplo: tabla clientes</h3>
        <table class="syntax-table">
            <thead>
                <tr><th>id</th><th>nombre</th><th>email</th><th>ciudad</th><th>fecha_registro</th></tr>
            </thead>
            <tbody>
                <tr><td>1</td><td>Juan Pérez</td><td>juan@mail.com</td><td>Buenos Aires</td><td>2023-01-15</td></tr>
                <tr><td>2</td><td>Ana García</td><td>ana@mail.com</td><td>Córdoba</td><td>2023-02-20</td></tr>
                <tr><td>3</td><td>Carlos López</td><td>carlos@mail.com</td><td>Rosario</td><td>2023-03-10</td></tr>
            </tbody>
        </table>
    </div>

    <div class="tutorial-section">
        <h2>SELECT — Consultar Datos</h2>
        <p>El comando más usado en SQL. Sirve para leer datos de una tabla.</p>

        <h3>Seleccionar todo</h3>
        <pre><code class="language-sql">-- El asterisco significa "todas las columnas"
SELECT * FROM clientes;</code></pre>

        <h3>Seleccionar columnas específicas</h3>
        <pre><code class="language-sql">-- Solo algunas columnas (más eficiente)
SELECT nombre, ciudad FROM clientes;</code></pre>

        <h3>Usar alias (AS)</h3>
        <pre><code class="language-sql">-- Renombrar columnas en el resultado
SELECT nombre AS cliente, precio AS precio_unitario
FROM productos;</code></pre>

        <div class="note-box tip">
            <strong>Buena práctica</strong>
            <p>Evitá usar <code>SELECT *</code> en aplicaciones reales. Especificá las columnas que necesitás — es más rápido y más claro.</p>
        </div>

        <a href="<?php echo asset('editor_db/?ejemplo=sql_01_basico_01'); ?>" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 1: SELECT básico
        </a>
    </div>

    <div class="tutorial-section">
        <h2>WHERE — Filtrar Resultados</h2>
        <p>Permite traer solo los registros que cumplen una condición.</p>

        <pre><code class="language-sql">-- Productos con precio mayor a $50
SELECT nombre, precio FROM productos WHERE precio > 50;

-- Clientes de Buenos Aires
SELECT nombre, ciudad FROM clientes WHERE ciudad = 'Buenos Aires';

-- Órdenes entregadas
SELECT * FROM ordenes WHERE estado = 'entregado';</code></pre>

        <h3>Operadores de comparación</h3>
        <table class="syntax-table">
            <thead>
                <tr><th>Operador</th><th>Descripción</th><th>Ejemplo</th></tr>
            </thead>
            <tbody>
                <tr><td><code>=</code></td><td>Igual</td><td><code>WHERE estado = 'enviado'</code></td></tr>
                <tr><td><code>!= / &lt;&gt;</code></td><td>Diferente</td><td><code>WHERE estado != 'cancelado'</code></td></tr>
                <tr><td><code>&gt;</code></td><td>Mayor que</td><td><code>WHERE precio > 100</code></td></tr>
                <tr><td><code>&lt;</code></td><td>Menor que</td><td><code>WHERE stock < 10</code></td></tr>
                <tr><td><code>BETWEEN</code></td><td>Entre valores</td><td><code>WHERE precio BETWEEN 20 AND 100</code></td></tr>
                <tr><td><code>LIKE</code></td><td>Patrón de texto</td><td><code>WHERE nombre LIKE 'Juan%'</code></td></tr>
                <tr><td><code>IN</code></td><td>En una lista</td><td><code>WHERE ciudad IN ('Córdoba', 'Rosario')</code></td></tr>
                <tr><td><code>IS NULL</code></td><td>Sin valor asignado</td><td><code>WHERE email IS NULL</code></td></tr>
            </tbody>
        </table>

        <h3>Operadores lógicos</h3>
        <pre><code class="language-sql">-- AND: ambas condiciones se cumplen
SELECT * FROM productos WHERE precio > 50 AND stock > 20;

-- OR: al menos una condición se cumple
SELECT * FROM clientes WHERE ciudad = 'Buenos Aires' OR ciudad = 'Córdoba';

-- NOT: negación
SELECT * FROM ordenes WHERE NOT estado = 'cancelado';</code></pre>

        <h3>ORDER BY y LIMIT</h3>
        <pre><code class="language-sql">-- Productos más caros primero
SELECT nombre, precio FROM productos ORDER BY precio DESC;

-- Los 5 productos más baratos
SELECT nombre, precio FROM productos ORDER BY precio ASC LIMIT 5;</code></pre>

        <a href="<?php echo asset('editor_db/?ejemplo=sql_01_basico_02'); ?>" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 2: WHERE y ORDER BY
        </a>
    </div>

    <div class="tutorial-section">
        <h2>JOIN — Combinar Tablas</h2>
        <p>
            Las bases de datos relacionales dividen la información en múltiples tablas para evitar
            repetición. <strong>JOIN</strong> las une en una sola consulta.
        </p>
        <p>
            La tabla <code>ordenes</code> guarda el <code>id_cliente</code> pero no el nombre.
            Con JOIN combinamos ambas tablas para obtenerlo.
        </p>

        <pre><code class="language-sql">-- INNER JOIN: trae solo las filas que coinciden en ambas tablas
SELECT 
    o.id        AS nro_orden,
    c.nombre    AS cliente,
    o.fecha,
    o.estado,
    o.total
FROM ordenes o
JOIN clientes c ON o.id_cliente = c.id;</code></pre>

        <div class="note-box info">
            <strong>Alias de tablas</strong>
            <p><code>FROM ordenes o</code> le da el alias <code>o</code> a la tabla. Así en vez de escribir <code>ordenes.id</code> escribís <code>o.id</code> — mucho más cómodo cuando tenés varias tablas.</p>
        </div>

        <h3>JOIN con tres tablas</h3>
        <pre><code class="language-sql">-- Qué productos tiene cada orden
SELECT 
    o.id        AS orden,
    c.nombre    AS cliente,
    p.nombre    AS producto,
    d.cantidad,
    d.precio_unitario
FROM detalle_ordenes d
JOIN ordenes   o ON d.id_orden    = o.id
JOIN clientes  c ON o.id_cliente  = c.id
JOIN productos p ON d.id_producto = p.id
ORDER BY o.id;</code></pre>

        <a href="<?php echo asset('editor_db/?ejemplo=sql_01_basico_03'); ?>" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 3: JOIN entre tablas
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Funciones de Agregación</h2>
        <p>Calculan un resultado a partir de múltiples filas.</p>

        <pre><code class="language-sql">-- Contar registros
SELECT COUNT(*) FROM clientes;
SELECT COUNT(*) FROM ordenes WHERE estado = 'entregado';

-- Suma total de ventas
SELECT SUM(total) FROM ordenes;

-- Precio promedio de productos
SELECT ROUND(AVG(precio), 2) AS precio_promedio FROM productos;

-- Producto más caro y más barato
SELECT MAX(precio) AS mas_caro, MIN(precio) AS mas_barato FROM productos;</code></pre>

        <h3>GROUP BY</h3>
        <p>Agrupa resultados y aplica funciones de agregación por grupo.</p>

        <pre><code class="language-sql">-- Cuántos productos hay por categoría
SELECT 
    c.nombre    AS categoria,
    COUNT(p.id) AS cantidad
FROM productos p
JOIN categorias c ON p.id_categoria = c.id
GROUP BY c.id, c.nombre
ORDER BY cantidad DESC;</code></pre>

        <h3>HAVING — Filtrar grupos</h3>
        <pre><code class="language-sql">-- Categorías con más de 3 productos
SELECT 
    c.nombre    AS categoria,
    COUNT(p.id) AS cantidad
FROM productos p
JOIN categorias c ON p.id_categoria = c.id
GROUP BY c.id, c.nombre
HAVING cantidad > 3
ORDER BY cantidad DESC;</code></pre>

        <div class="note-box info">
            <strong>WHERE vs HAVING</strong>
            <p><code>WHERE</code> filtra filas individuales antes de agrupar. <code>HAVING</code> filtra grupos después de aplicar GROUP BY.</p>
        </div>

        <a href="<?php echo asset('editor_db/?ejemplo=sql_01_basico_04'); ?>" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 4: GROUP BY y agregación
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Modificar Datos</h2>

        <h3>INSERT — Insertar registros</h3>
        <pre><code class="language-sql">INSERT INTO clientes (nombre, email, ciudad, fecha_registro)
VALUES ('Lucía Romero', 'lucia@mail.com', 'Mendoza', '2025-01-10');</code></pre>

        <div class="note-box info">
            <strong>AUTO_INCREMENT</strong>
            <p>No incluyas el campo <code>id</code> en el INSERT si es AUTO_INCREMENT. MySQL lo genera automáticamente.</p>
        </div>

        <h3>UPDATE — Actualizar registros</h3>
        <pre><code class="language-sql">-- Actualizar la ciudad de un cliente
UPDATE clientes SET ciudad = 'Rosario' WHERE id = 3;

-- Aumentar 10% el precio de electrónica
UPDATE productos SET precio = precio * 1.10 WHERE id_categoria = 1;</code></pre>

        <div class="note-box warning">
            <strong>Siempre usá WHERE en UPDATE</strong>
            <p><code>UPDATE clientes SET ciudad = 'Rosario'</code> sin WHERE actualiza TODOS los registros. Siempre verificá tu condición.</p>
        </div>

        <h3>DELETE — Eliminar registros</h3>
        <pre><code class="language-sql">-- Eliminar un cliente específico
DELETE FROM clientes WHERE id = 15;

-- Eliminar órdenes canceladas
DELETE FROM ordenes WHERE estado = 'cancelado';</code></pre>

        <div class="note-box warning">
            <strong>DELETE sin WHERE</strong>
            <p><code>DELETE FROM clientes;</code> borra TODA la tabla. Una vez ejecutado no hay vuelta atrás sin un backup.</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Tipos de Datos Comunes</h2>
        <table class="syntax-table">
            <thead>
                <tr><th>Tipo</th><th>Descripción</th><th>Ejemplo en tutorial_db</th></tr>
            </thead>
            <tbody>
                <tr><td><code>INT</code></td><td>Número entero</td><td><code>id INT AUTO_INCREMENT</code></td></tr>
                <tr><td><code>VARCHAR(n)</code></td><td>Texto hasta n caracteres</td><td><code>nombre VARCHAR(100)</code></td></tr>
                <tr><td><code>TEXT</code></td><td>Texto largo</td><td><code>descripcion TEXT</code></td></tr>
                <tr><td><code>DECIMAL(m,d)</code></td><td>Decimal exacto</td><td><code>precio DECIMAL(10,2)</code></td></tr>
                <tr><td><code>DATE</code></td><td>Fecha (YYYY-MM-DD)</td><td><code>fecha_registro DATE</code></td></tr>
                <tr><td><code>DATETIME</code></td><td>Fecha y hora</td><td><code>creado_en DATETIME</code></td></tr>
                <tr><td><code>ENUM</code></td><td>Valor de una lista fija</td><td><code>estado ENUM('pendiente','enviado'...)</code></td></tr>
                <tr><td><code>BOOLEAN</code></td><td>Verdadero/Falso (0/1)</td><td><code>activo BOOLEAN</code></td></tr>
            </tbody>
        </table>
    </div>

    <div class="tutorial-section">
        <h2>Conectar MySQL desde PHP</h2>
        <p>Una vez que dominás SQL, podés usarlo desde PHP para construir aplicaciones dinámicas:</p>

        <pre><code class="language-php">&lt;?php
// 1. Conectar a la base de datos
$conexion = mysqli_connect("localhost", "root", "", "tutorial_db");

if (!$conexion) {
    die("Error: " . mysqli_connect_error());
}

// 2. Ejecutar un SELECT
$sql       = "SELECT nombre, ciudad FROM clientes ORDER BY nombre";
$resultado = mysqli_query($conexion, $sql);

// 3. Recorrer los resultados
while ($fila = mysqli_fetch_assoc($resultado)) {
    echo $fila['nombre'] . " — " . $fila['ciudad'] . "&lt;br&gt;";
}

// 4. Cerrar conexión
mysqli_close($conexion);
?&gt;</code></pre>

        <div class="note-box warning">
            <strong>SQL Injection</strong>
            <p>Nunca insertes datos del usuario directamente en una query. Usá <strong>prepared statements</strong> con <code>mysqli_prepare()</code> para proteger tu aplicación.</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Buenas Prácticas</h2>
        <ul>
            <li><strong>Siempre usá WHERE en UPDATE y DELETE:</strong> sin él afectás toda la tabla</li>
            <li><strong>Nombres descriptivos en minúsculas:</strong> <code>fecha_registro</code> en vez de <code>fr</code></li>
            <li><strong>PRIMARY KEY en todas las tablas:</strong> generalmente un <code>id INT AUTO_INCREMENT</code></li>
            <li><strong>FOREIGN KEY para relacionar tablas:</strong> garantizan integridad referencial</li>
            <li><strong>Especificá columnas en SELECT:</strong> evitá <code>SELECT *</code> en producción</li>
            <li><strong>Hacé backups regularmente:</strong> <code>mysqldump -u root tutorial_db > backup.sql</code></li>
            <li><strong>Usá prepared statements desde PHP:</strong> previenen SQL Injection</li>
        </ul>
    </div>

</div>
    </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>