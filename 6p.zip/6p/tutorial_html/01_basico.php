<?php
/**
 * Tutorial: HTML Básico
 */

$pageTitle = "HTML Básico - Tutorial Interactivo";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="layout-container">
    <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

    <main class="main-content">
<div class="tutorial-container" style="--lang-color: #E34F26">

    <div class="tutorial-intro html">
        <h1>HTML Básico</h1>
        <p>Aprendé la estructura fundamental de HTML. Es el lenguaje de marcado que estructura todo el contenido web.</p>
    </div>

    <div class="tutorial-section">
        <h2>¿Qué es HTML?</h2>
        <p>
            <strong>HTML (HyperText Markup Language)</strong> es el lenguaje estándar para crear páginas web.
            No es un lenguaje de programación — es un lenguaje de <strong>marcado</strong> que define la estructura del contenido.
        </p>
        <pre><code class="language-markup">&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
    &lt;title&gt;Mi Primera Página&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;h1&gt;Hola Mundo&lt;/h1&gt;
    &lt;p&gt;Este es mi primer párrafo.&lt;/p&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
        <div class="note-box info">
            <strong>Importante</strong>
            <p>HTML usa <strong>etiquetas</strong> para marcar diferentes tipos de contenido. La mayoría tienen apertura <code>&lt;tag&gt;</code> y cierre <code>&lt;/tag&gt;</code>.</p>
        </div>
        <a href="../editor/index.php?ejemplo=html_01_basico_01" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 1: Hola Mundo
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Estructura Básica</h2>
        <p>Todo documento HTML sigue esta estructura:</p>
        <pre><code class="language-markup">&lt;!DOCTYPE html&gt;        &lt;!-- Declara que es HTML5 --&gt;
&lt;html lang="es"&gt;       &lt;!-- Elemento raíz --&gt;

&lt;head&gt;                 &lt;!-- Metadatos, no visible en la página --&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;
    &lt;title&gt;Título de la Página&lt;/title&gt;
&lt;/head&gt;

&lt;body&gt;                 &lt;!-- Contenido visible --&gt;
    &lt;h1&gt;Contenido aquí&lt;/h1&gt;
&lt;/body&gt;

&lt;/html&gt;</code></pre>

        <div class="card-grid">
            <div class="info-card">
                <h4>&lt;!DOCTYPE html&gt;</h4>
                <code>Declara HTML5</code>
            </div>
            <div class="info-card">
                <h4>&lt;html&gt;</h4>
                <code>Elemento raíz</code>
            </div>
            <div class="info-card">
                <h4>&lt;head&gt;</h4>
                <code>Metadatos</code>
            </div>
            <div class="info-card">
                <h4>&lt;body&gt;</h4>
                <code>Contenido visible</code>
            </div>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Etiquetas de Texto</h2>

        <h3>Encabezados</h3>
        <pre><code class="language-markup">&lt;h1&gt;Encabezado principal&lt;/h1&gt;
&lt;h2&gt;Encabezado de nivel 2&lt;/h2&gt;
&lt;h3&gt;Encabezado de nivel 3&lt;/h3&gt;</code></pre>
        <div class="note-box warning">
            <strong>Jerarquía</strong>
            <p>Usá solo un <code>&lt;h1&gt;</code> por página. Los demás van en orden descendente.</p>
        </div>

        <h3>Párrafos y Formato</h3>
        <pre><code class="language-markup">&lt;p&gt;Esto es un párrafo de texto.&lt;/p&gt;

&lt;strong&gt;Texto en negrita&lt;/strong&gt;
&lt;em&gt;Texto en cursiva&lt;/em&gt;

&lt;br&gt;   &lt;!-- Salto de línea --&gt;
&lt;hr&gt;   &lt;!-- Línea horizontal --&gt;</code></pre>
        <a href="../editor/index.php?ejemplo=html_01_basico_02" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 2: Texto y formato
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Listas y Enlaces</h2>

        <h3>Lista desordenada (bullets)</h3>
        <pre><code class="language-markup">&lt;ul&gt;
    &lt;li&gt;Primer elemento&lt;/li&gt;
    &lt;li&gt;Segundo elemento&lt;/li&gt;
    &lt;li&gt;Tercer elemento&lt;/li&gt;
&lt;/ul&gt;</code></pre>

        <h3>Lista ordenada (números)</h3>
        <pre><code class="language-markup">&lt;ol&gt;
    &lt;li&gt;Paso 1&lt;/li&gt;
    &lt;li&gt;Paso 2&lt;/li&gt;
    &lt;li&gt;Paso 3&lt;/li&gt;
&lt;/ol&gt;</code></pre>

        <h3>Enlaces</h3>
        <pre><code class="language-markup">&lt;!-- Enlace externo --&gt;
&lt;a href="https://google.com"&gt;Ir a Google&lt;/a&gt;

&lt;!-- Abrir en nueva pestaña --&gt;
&lt;a href="https://google.com" target="_blank"&gt;Google&lt;/a&gt;</code></pre>
        <a href="../editor/index.php?ejemplo=html_01_basico_03" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 3: Listas y enlaces
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Contenedores y Semántica</h2>
        <p>HTML5 introdujo etiquetas con significado específico — mejoran la accesibilidad y el SEO.</p>
        <pre><code class="language-markup">&lt;!-- Semánticas HTML5 --&gt;
&lt;header&gt;Encabezado del sitio&lt;/header&gt;
&lt;nav&gt;Menú de navegación&lt;/nav&gt;
&lt;main&gt;Contenido principal&lt;/main&gt;
&lt;section&gt;Sección de contenido&lt;/section&gt;
&lt;article&gt;Artículo independiente&lt;/article&gt;
&lt;footer&gt;Pie de página&lt;/footer&gt;

&lt;!-- Genéricas --&gt;
&lt;div&gt;Bloque genérico&lt;/div&gt;
&lt;span&gt;Línea genérica&lt;/span&gt;</code></pre>
        <div class="note-box tip">
            <strong>¿div o semántica?</strong>
            <p>Usá las etiquetas semánticas cuando tengan sentido. <code>&lt;div&gt;</code> queda para contenedores sin significado propio.</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Atributos Comunes</h2>
        <p>Las etiquetas pueden tener atributos que agregan información o comportamiento:</p>
        <table class="syntax-table">
            <thead>
                <tr>
                    <th>Atributo</th>
                    <th>Uso</th>
                    <th>Ejemplo</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>id</code></td>
                    <td>Identificador único</td>
                    <td><code>&lt;div id="menu"&gt;</code></td>
                </tr>
                <tr>
                    <td><code>class</code></td>
                    <td>Clasificación para CSS</td>
                    <td><code>&lt;p class="destacado"&gt;</code></td>
                </tr>
                <tr>
                    <td><code>href</code></td>
                    <td>URL del enlace</td>
                    <td><code>&lt;a href="page.html"&gt;</code></td>
                </tr>
                <tr>
                    <td><code>src</code></td>
                    <td>Fuente de imagen/script</td>
                    <td><code>&lt;img src="foto.jpg"&gt;</code></td>
                </tr>
                <tr>
                    <td><code>alt</code></td>
                    <td>Texto alternativo imagen</td>
                    <td><code>&lt;img alt="Logo"&gt;</code></td>
                </tr>
                <tr>
                    <td><code>target</code></td>
                    <td>Dónde abrir el enlace</td>
                    <td><code>&lt;a target="_blank"&gt;</code></td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="tutorial-section">
        <h2>Ejemplo Completo</h2>
        <p>Una página HTML completa con estructura semántica:</p>
        <pre><code class="language-markup">&lt;!DOCTYPE html&gt;
&lt;html lang="es"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;title&gt;Mi Blog&lt;/title&gt;
    &lt;style&gt;
        body { font-family: Arial, sans-serif; padding: 20px; }
        header { background: #333; color: white; padding: 20px; }
        article { background: #f5f5f5; padding: 20px; margin: 20px 0; }
    &lt;/style&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;header&gt;
        &lt;h1&gt;Mi Blog&lt;/h1&gt;
        &lt;nav&gt;
            &lt;a href="#"&gt;Inicio&lt;/a&gt;
            &lt;a href="#"&gt;Artículos&lt;/a&gt;
        &lt;/nav&gt;
    &lt;/header&gt;
    &lt;main&gt;
        &lt;article&gt;
            &lt;h2&gt;Mi Primer Artículo&lt;/h2&gt;
            &lt;p&gt;Contenido del artículo aquí.&lt;/p&gt;
        &lt;/article&gt;
    &lt;/main&gt;
    &lt;footer&gt;
        &lt;p&gt;&amp;copy; 2026 Mi Blog&lt;/p&gt;
    &lt;/footer&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
        <a href="../editor/index.php?ejemplo=html_01_basico_04" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 4: Blog completo
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Buenas Prácticas</h2>
        <ul>
            <li><strong>Siempre cerrá las etiquetas:</strong> <code>&lt;p&gt;...&lt;/p&gt;</code></li>
            <li><strong>Usá minúsculas:</strong> <code>&lt;div&gt;</code> en vez de <code>&lt;DIV&gt;</code></li>
            <li><strong>Indentá el código:</strong> facilita la lectura</li>
            <li><strong>Un <code>&lt;h1&gt;</code> por página:</strong> para SEO</li>
            <li><strong>Siempre incluí <code>alt</code> en imágenes:</strong> accesibilidad</li>
            <li><strong>Usá etiquetas semánticas:</strong> <code>&lt;header&gt;</code>, <code>&lt;nav&gt;</code>, etc. en vez de <code>&lt;div&gt;</code> para todo</li>
        </ul>
    </div>

</div>
    </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>