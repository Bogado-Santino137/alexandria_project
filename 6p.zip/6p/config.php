<?php
/**
 * CONFIGURACIÓN GLOBAL
 * ====================
 * Sistema de rutas dinámico que funciona desde cualquier nivel del proyecto
 * 
 * @version 2.1 — fix WEB_ROOT vacío en raíz del dominio
 */

// Detectar el directorio base del proyecto
define('PROJECT_ROOT', dirname(__FILE__));

// Detectar la ruta web base (para URLs)
// Ejemplo: http://localhost/mic/6p → WEB_ROOT = '/mic/6p'
// Ejemplo: https://midominio.com/  → WEB_ROOT = ''
$script_path = dirname($_SERVER['SCRIPT_NAME']);
$web_root = $script_path;

// Si estamos en una subcarpeta (php/, mysql/, etc), subir al nivel raíz
$path_parts = explode('/', trim($script_path, '/'));
$last_part = end($path_parts);

// Lista de carpetas de ejercicios (no son el root)
$exercise_folders = [
    'editor_db', 'editor', 'js_system', 'css_system', 'ejemplos',
    'tutorial_php', 'tutorial_html', 'tutorial_js',
    'tutorial_mysql', 'tutorial_python', 'tutorial_css'
];

if (in_array($last_part, $exercise_folders)) {
    array_pop($path_parts);
    $web_root = '/' . implode('/', $path_parts);
}

// Fix: si el proyecto está en la raíz del dominio, WEB_ROOT queda
// como '/' o '' — normalizamos a '' para evitar URLs con doble barra
if ($web_root === '/') {
    $web_root = '';
}

define('WEB_ROOT', $web_root);

// Rutas para recursos estáticos (CSS, JS, imágenes)
define('CSS_PATH',    WEB_ROOT . '/css_system');
define('JS_PATH',     WEB_ROOT . '/js_system');
define('ASSETS_PATH', WEB_ROOT . '/includes/assets');

// Rutas para includes PHP (rutas del sistema de archivos)
define('INCLUDES_PATH', PROJECT_ROOT . '/includes');

/**
 * Genera URLs de recursos — nunca produce doble barra
 */
function asset($path) {
    return WEB_ROOT . '/' . ltrim($path, '/');
}

function css($file) {
    return CSS_PATH . '/' . ltrim($file, '/');
}

function js($file) {
    return JS_PATH . '/' . ltrim($file, '/');
}

function img($file) {
    return ASSETS_PATH . '/' . ltrim($file, '/');
}

/*
// Debug: descomentar para verificar rutas en producción
echo "<!-- DEBUG RUTAS\n";
echo "SCRIPT_NAME: " . $_SERVER['SCRIPT_NAME'] . "\n";
echo "WEB_ROOT: " . WEB_ROOT . "\n";
echo "CSS_PATH: " . CSS_PATH . "\n";
echo "JS_PATH: " . JS_PATH . "\n";
echo "ASSETS_PATH: " . ASSETS_PATH . "\n";
echo "-->\n";
*/
?>