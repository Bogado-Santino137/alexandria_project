let editor, hasChanges = false, shortcutShown = true, currentTheme = 'dark';
let exampleQuery = '';
const $ = id => document.getElementById(id);

/*--------------------------- DATOS BD ---------------------------*/

const DB_TABLES = [
    { name: 'clientes',        rows: 15 },
    { name: 'productos',       rows: 29 },
    { name: 'categorias',      rows: 8  },
    { name: 'ordenes',         rows: 25 },
    { name: 'detalle_ordenes', rows: 55 },
];

const DB_COLUMNS = {
    clientes:        ['id', 'nombre', 'email', 'ciudad', 'pais', 'fecha_registro'],
    productos:       ['id', 'nombre', 'precio', 'stock', 'id_categoria'],
    categorias:      ['id', 'nombre'],
    ordenes:         ['id', 'id_cliente', 'fecha', 'total', 'estado'],
    detalle_ordenes: ['id', 'id_orden', 'id_producto', 'cantidad', 'precio_unitario'],
};

/*--------------------------- SQL HINT PROVIDER ---------------------------*/

const SQL_KEYWORDS = [
    // DML
    'SELECT', 'FROM', 'WHERE', 'AND', 'OR', 'NOT', 'IN', 'BETWEEN', 'LIKE',
    'IS', 'NULL', 'IS NULL', 'IS NOT NULL', 'AS', 'DISTINCT', 'ALL',
    'INSERT', 'INTO', 'VALUES', 'UPDATE', 'SET', 'DELETE',
    // Joins
    'JOIN', 'INNER JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'FULL JOIN', 'ON',
    // Agrupación y orden
    'GROUP BY', 'ORDER BY', 'HAVING', 'LIMIT', 'OFFSET', 'ASC', 'DESC',
    // DDL
    'CREATE', 'TABLE', 'ALTER', 'DROP', 'INDEX', 'VIEW',
    // Funciones de agregación
    'COUNT', 'SUM', 'AVG', 'MIN', 'MAX',
    // Funciones de texto
    'CONCAT', 'LENGTH', 'UPPER', 'LOWER', 'TRIM', 'SUBSTRING', 'REPLACE',
    // Funciones de fecha
    'NOW', 'CURDATE', 'DATE', 'YEAR', 'MONTH', 'DAY', 'DATEDIFF',
    // Funciones numéricas
    'ROUND', 'FLOOR', 'CEIL', 'ABS', 'MOD',
    // Condicional
    'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'IF', 'IFNULL', 'COALESCE',
    // Otros
    'SHOW', 'TABLES', 'DATABASES', 'USE', 'DESCRIBE', 'EXPLAIN',
];

function sqlHint(cm) {
    const cursor = cm.getCursor();
    const line   = cm.getLine(cursor.line);
    const start  = cursor.ch;

    let wordStart = start;
    while (wordStart > 0 && /[\w.]/.test(line.charAt(wordStart - 1))) wordStart--;

    const word    = line.slice(wordStart, start);
    const wordLow = word.toLowerCase();
    const suggestions = new Set();

    // Keywords — mismo case que el usuario escribió
    const useUpper = word === word.toUpperCase() && word.length > 0;
    SQL_KEYWORDS.forEach(kw => {
        const candidate = useUpper ? kw : kw.toLowerCase();
        if (candidate.toLowerCase().startsWith(wordLow)) suggestions.add(candidate);
    });

    // Tablas
    DB_TABLES.forEach(t => {
        if (t.name.startsWith(wordLow)) suggestions.add(t.name);
    });

    // Alias tabla.columna
    if (word.includes('.')) {
        const [alias, partial] = word.split('.');
        const match = DB_TABLES.find(t => t.name.startsWith(alias) || alias === t.name[0]);
        if (match && DB_COLUMNS[match.name]) {
            return {
                list: DB_COLUMNS[match.name].filter(c => c.startsWith(partial)).map(c => alias + '.' + c),
                from: CodeMirror.Pos(cursor.line, wordStart),
                to:   CodeMirror.Pos(cursor.line, start),
            };
        }
    }

    return {
        list: [...suggestions],
        from: CodeMirror.Pos(cursor.line, wordStart),
        to:   CodeMirror.Pos(cursor.line, start),
    };
}

CodeMirror.registerHelper('hint', 'sql', sqlHint);

/*--------------------------- INIT ---------------------------*/

function init() {
    exampleQuery     = $('sqlEditor').value;
    const saved      = loadFromStorage();
    const startQuery = saved || exampleQuery;
    hasChanges       = !!(saved && saved !== exampleQuery);

    editor = CodeMirror.fromTextArea($('sqlEditor'), {
        mode:              'text/x-sql',
        theme:             'dracula',
        lineNumbers:       true,
        indentUnit:        4,
        indentWithTabs:    false,
        lineWrapping:      false,
        matchBrackets:     true,
        autoCloseBrackets: true,
        extraKeys: {
            'Ctrl-Space': (cm) => CodeMirror.showHint(cm, sqlHint, { completeSingle: false }),
            'Ctrl-Enter': () => { runQuery(); return false; },
            'Cmd-Enter':  () => { runQuery(); return false; },
        },
        hintOptions: { hint: sqlHint, completeSingle: false }
    });

    editor.setValue(startQuery);
    editor.on('change', () => { checkChanges(); saveToStorage(); });

    loadTheme();
    updateStats();
    if (hasChanges) updateChangeIndicator();

    renderTablesList();

    $('btnRun').onclick   = runQuery;
    $('btnCopy').onclick  = copyCode;
    $('btnClear').onclick = clearCode;
    $('btnTheme').onclick = toggleTheme;

    // Ctrl+Enter cuando el foco NO está en el editor (ej: botón enfocado)
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !editor.hasFocus()) {
            e.preventDefault();
            runQuery();
        }
    });

    setupResize();
    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    new ResizeObserver(updateDimensions).observe($('resultBody'));
}

/*--------------------------- TEMA ---------------------------*/

function applyTheme(theme) {
    currentTheme = theme;
    document.body.dataset.theme = theme;
    editor.setOption('theme', theme === 'dark' ? 'dracula' : 'eclipse');
    $('btnTheme').innerHTML = theme === 'dark'
        ? '<span class="theme-icon--dark">◑</span>'
        : '<span class="theme-icon--light">◐</span>';
}

function toggleTheme() {
    const next = currentTheme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    localStorage.setItem('editor_db_theme', next);
}

function loadTheme() {
    const saved = localStorage.getItem('editor_db_theme');
    if (saved) applyTheme(saved);
}

/*--------------------------- CAMBIOS ---------------------------*/

function checkChanges() {
    const changed = editor.getValue() !== exampleQuery;
    if (changed !== hasChanges) { hasChanges = changed; updateChangeIndicator(); }
    else { updateStats(); }
}

function updateChangeIndicator() {
    $('editorStats').classList.toggle('changed', hasChanges);
    updateStats();
}

/*--------------------------- STATS ---------------------------*/

function updateStats() {
    $('editorStats').textContent = `${editor.lineCount()} líneas • ${editor.getValue().length} caracteres`;
}

function updateDimensions() {
    const el  = $('resultBody');
    const dim = $('resultDimensions');
    if (!el || !dim) return;
    dim.textContent = `${el.clientWidth} x ${el.clientHeight}`;
}

/*--------------------------- TABLAS ---------------------------*/

function renderTablesList() {
    $('tablesList').innerHTML = DB_TABLES.map(t => `
        <div class="table-item" data-table="${t.name}">
            <div class="table-item-left">
                <svg class="table-icon" width="13" height="13" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24">
                    <rect x="3" y="3" width="18" height="18" rx="2"/>
                    <path d="M3 9h18M3 15h18M9 3v18"/>
                </svg>
                <span class="table-name">${t.name}</span>
            </div>
            <span class="table-rows">${t.rows}</span>
        </div>
    `).join('');
}

function loadTable(name, el) {
    document.querySelectorAll('.table-item').forEach(i => i.classList.remove('active'));
    el.classList.add('active');
    const q = `SELECT * FROM ${name};`;
    editor.setValue(q);
    // No pisamos exampleQuery — Restaurar siempre vuelve al ejemplo original
    hasChanges = q !== exampleQuery;
    updateChangeIndicator();
    saveToStorage();
}

/*--------------------------- EJECUCIÓN ---------------------------*/

async function runQuery() {
    const rawQuery = editor.getValue().trim();
    if (!rawQuery) { showToast('Escribí un query SQL primero', 'error'); return; }

    // Limpiar comentarios para detectar si hay contenido real
    const clean = rawQuery.replace(/--[^\n]*/g, '').replace(/#[^\n]*/g, '').trim();
    if (!clean) { showToast('El editor solo tiene comentarios', 'error'); return; }

    const btn = $('btnRun');
    btn.disabled  = true;
    btn.innerHTML = '<span class="spin">⚙️</span> Ejecutando...';
    if (shortcutShown) shortcutShown = false;

    const timeoutId = setTimeout(() => {
        btn.disabled  = false;
        btn.innerHTML = 'Ejecutar';
        renderError('El query tardó más de 4 segundos. Revisá si hay loops o joins muy pesados.');
        showToast('Timeout: query tardó demasiado', 'error');
    }, 4000);

    const start = Date.now();

    try {
        const form = new FormData();
        form.append('query', rawQuery);
        const base     = (document.body.dataset.baseUrl || '').replace(/\/$/, '');
        const response = await fetch(base + '/editor_db/execute_db.php', { method: 'POST', body: form });
        clearTimeout(timeoutId);

        if (!response.ok) {
            let msg = `Error ${response.status}: ${response.statusText}`;
            try { const t = await response.text(); if (t && t.length < 200) msg = t; } catch {}
            showToast(msg, 'error');
            renderError(msg);
            return;
        }

        const data = await response.json();
        const ms   = Date.now() - start;

        if (data.error) {
            renderError(data.error);
            setResultMeta('error', 'Error');
            showToast('Error en el query', 'error');
        } else if (data.type === 'select') {
            renderSelectResult(data);
            setResultMeta('success', `${data.count} fila${data.count !== 1 ? 's' : ''} • ${ms}ms`);
            showToast(`${data.count} resultado${data.count !== 1 ? 's' : ''}`, 'success');
        } else if (data.type === 'write') {
            renderWriteResult(data, ms);
            setResultMeta('success', `${data.affected} afectada${data.affected !== 1 ? 's' : ''} • ${ms}ms`);
            showToast(data.message || 'Query ejecutado', 'success');
        }
    } catch (e) {
        clearTimeout(timeoutId);
        const msg = e.message !== 'Failed to fetch' ? e.message.substring(0, 60) : 'Error de conexión con el servidor';
        showToast(msg, 'error');
        renderError('No se pudo conectar con execute_db.php. Verificá que el archivo existe.');
    } finally {
        btn.disabled  = false;
        btn.innerHTML = shortcutShown ? 'Ejecutar <span class="shortcut" id="runShortcut">Ctrl+Enter</span>' : 'Ejecutar';
    }
}

/*--------------------------- RENDER RESULTADOS ---------------------------*/

function setResultMeta(type, text) {
    $('resultMeta').innerHTML = text ? `<span class="result-badge ${type}">${text}</span>` : '';
}

/*function renderError(msg) {
    $('resultBody').innerHTML = `
        <div class="error-box">
            <h4>&#x2715; Error</h4>
            <p>${escHtml(msg)}</p>
        </div>`;
}*/

function renderError(msg) {
    $('resultBody').innerHTML = `
        <div class="error-box">
            <h4>Error</h4>
            <p>${escHtml(msg)}</p>
        </div>`;
}

function renderSelectResult(data) {
    if (!data.rows || data.rows.length === 0) {
        $('resultBody').innerHTML = '<div class="no-rows">La consulta no devolvió resultados.</div>';
        return;
    }
    const thead = data.columns.map(c => `<th>${escHtml(c)}</th>`).join('');
    const tbody = data.rows.map(row =>
        '<tr>' + data.columns.map(c => {
            const val = row[c];
            if (val === null || val === undefined) return '<td class="null-val">NULL</td>';
            return `<td title="${escHtml(String(val))}">${escHtml(String(val))}</td>`;
        }).join('') + '</tr>'
    ).join('');

    $('resultBody').innerHTML = `
        <table class="sql-result-table">
            <thead><tr>${thead}</tr></thead>
            <tbody>${tbody}</tbody>
        </table>`;
}

function renderWriteResult(data, ms) {
    $('resultBody').innerHTML = `
        <div class="write-result">
            <div class="write-result-icon">✓</div>
            <div class="write-result-info">
                <h4>Query ejecutado con éxito</h4>
                <p>${escHtml(data.message || '')}</p>
                <span class="time-badge">${ms}ms</span>
            </div>
        </div>`;
}

function escHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/*--------------------------- UTILIDADES ---------------------------*/

async function copyCode() {
    try { await navigator.clipboard.writeText(editor.getValue()); showToast('Código copiado', 'success'); }
    catch { showToast('Error al copiar', 'error'); }
}

function clearCode() {
    if (!hasChanges) { showToast('No hay cambios para restaurar', 'error'); return; }
    const snapshot = editor.getValue();
    editor.setValue(exampleQuery);
    hasChanges = false;
    updateChangeIndicator();
    saveToStorage();
    setResultMeta('', '');
    $('resultBody').innerHTML = getPlaceholderHTML();
    document.querySelectorAll('.table-item').forEach(el => el.classList.remove('active'));

    showToastWithUndo('Código restaurado', () => {
        editor.setValue(snapshot);
        hasChanges = true;
        updateChangeIndicator();
    });
}

function getPlaceholderHTML() {
    return `
        <div class="result-placeholder">
            <svg width="44" height="44" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                <ellipse cx="12" cy="5" rx="9" ry="3"/>
                <path d="M3 5v14c0 1.66 4.03 3 9 3s9-1.34 9-3V5"/>
                <path d="M3 12c0 1.66 4.03 3 9 3s9-1.34 9-3"/>
            </svg>
            <p>Escribí un query SQL y hacé clic en <strong>Ejecutar</strong><br>
            o presioná <kbd>Ctrl</kbd> + <kbd>Enter</kbd></p>
        </div>`;
}

/*--------------------------- TOAST ---------------------------*/

function showToastWithUndo(msg, onUndo) {
    const t = $('dbToast');
    t.innerHTML = `${msg} — <span id="toastUndo" style="text-decoration:underline;cursor:pointer;font-weight:600">Deshacer</span>`;
    t.className = 'toast show';
    $('toastUndo').onclick = () => { onUndo(); t.classList.remove('show'); };
    clearTimeout(t._timeout);
    t._timeout = setTimeout(() => t.classList.remove('show'), 4000);
}

function showToast(msg, type = 'success') {
    const t = $('dbToast');
    t.textContent = msg;
    t.className   = `toast show ${type}`;
    clearTimeout(t._timeout);
    t._timeout = setTimeout(() => t.classList.remove('show'), 3000);
}

/*--------------------------- STORAGE ---------------------------*/

function getEjemplo() {
    try { return new URL(window.location.href).searchParams.get('ejemplo') || 'default'; }
    catch { return 'default'; }
}

let _saveTimeout = null;
function saveToStorage() {
    clearTimeout(_saveTimeout);
    _saveTimeout = setTimeout(() => {
        try { localStorage.setItem(`editor_sql_${getEjemplo()}`, editor.getValue()); } catch {}
    }, 500);
}

function loadFromStorage() {
    try { return localStorage.getItem(`editor_sql_${getEjemplo()}`); }
    catch { return null; }
}

/*--------------------------- RESIZE ---------------------------*/

function setupResize() {
    // ── Resize horizontal: explorador BD ──
    let isResizingH = false;
    const explorer  = $('dbExplorer');

    function onStartH(e) {
        isResizingH = true;
        $('divider').classList.add('dragging');
        document.body.style.cursor     = 'col-resize';
        document.body.style.userSelect = 'none';
        e.preventDefault();
    }

    function onMoveH(clientX) {
        if (!isResizingH) return;
        requestAnimationFrame(() => {
            const rect     = document.querySelector('.panels').getBoundingClientRect();
            const newWidth = Math.min(320, Math.max(160, rect.right - clientX));
            explorer.style.width = newWidth + 'px';
            editor.refresh();
        });
    }

    function onEndH() {
        if (!isResizingH) return;
        isResizingH = false;
        $('divider').classList.remove('dragging');
        document.body.style.cursor     = '';
        document.body.style.userSelect = '';
    }

    // ── Resize vertical: editor SQL vs resultado ──
    let isResizingV  = false;
    const editorArea = $('sqlEditorArea');
    const editorPanel = document.querySelector('.editor-panel');

    function onStartV(e) {
        isResizingV = true;
        $('dividerH').classList.add('dragging');
        document.body.style.cursor     = 'row-resize';
        document.body.style.userSelect = 'none';
        e.preventDefault();
    }

    function onMoveV(clientY) {
        if (!isResizingV) return;
        requestAnimationFrame(() => {
            const rect = editorPanel.getBoundingClientRect();
            const newH = Math.min(rect.height - 80, Math.max(80, clientY - rect.top));
            editorArea.style.flex = `0 0 ${newH}px`;
            editor.refresh();
            updateDimensions();
        });
    }

    function onEndV() {
        if (!isResizingV) return;
        isResizingV = false;
        $('dividerH').classList.remove('dragging');
        document.body.style.cursor     = '';
        document.body.style.userSelect = '';
    }

    // ── Event listeners compartidos ──
    let lastMove = 0, lastTouch = 0;
    const throttle = (last, fn) => { const n = Date.now(); if (n - last < 16) return last; fn(); return n; };

    $('divider').onmousedown   = onStartH;
    $('divider').ontouchstart  = onStartH;
    $('dividerH').onmousedown  = onStartV;
    $('dividerH').ontouchstart = onStartV;

    document.onmousemove = (e) => { lastMove  = throttle(lastMove,  () => { if (isResizingH) onMoveH(e.clientX); if (isResizingV) onMoveV(e.clientY); }); };
    document.ontouchmove = (e) => { if (!e.touches[0]) return; lastTouch = throttle(lastTouch, () => { if (isResizingH) onMoveH(e.touches[0].clientX); if (isResizingV) onMoveV(e.touches[0].clientY); }); };
    document.onmouseup  = () => { onEndH(); onEndV(); };
    document.ontouchend = () => { onEndH(); onEndV(); };
}

/*--------------------------- ARRANQUE ---------------------------*/

// Registrar click del explorador una sola vez
$('tablesList')?.addEventListener('click', (e) => {
    const item = e.target.closest('.table-item');
    if (item) loadTable(item.dataset.table, item);
});

document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', init) : init();