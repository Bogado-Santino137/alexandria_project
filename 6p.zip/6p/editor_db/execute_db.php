<?php
require_once __DIR__ . '/../vendor/autoload.php';
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

header('Content-Type: application/json; charset=UTF-8');
header('X-Content-Type-Options: nosniff');

// --- VALIDAR REQUEST ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['query'])) {
    echo json_encode(['error' => 'No hay query para ejecutar.']);
    exit;
}

$query = trim($_POST['query']);

if (strlen($query) > 5000) {
    echo json_encode(['error' => 'Query demasiado larga (máx. 5000 caracteres).']);
    exit;
}

// --- SEGURIDAD: BLACKLIST ---
$forbidden = [
    'DROP', 'CREATE', 'ALTER', 'TRUNCATE', 'RENAME',
    'GRANT', 'REVOKE', 'LOCK', 'UNLOCK',
    'LOAD', 'OUTFILE', 'INFILE',
    'SLEEP', 'BENCHMARK', 'GET_LOCK',
    'SHUTDOWN', 'KILL',
];

$queryUpper = strtoupper($query);

foreach ($forbidden as $cmd) {
    if (preg_match('/\b' . $cmd . '\b/', $queryUpper)) {
        echo json_encode([
            'error' => "Comando no permitido: <strong>$cmd</strong>. " .
                       "En este editor solo podés usar SELECT, INSERT, UPDATE y DELETE."
        ]);
        exit;
    }
}

// Detectar múltiples statements — eliminar strings antes de contar ";"
$cleanQuery = preg_replace(["/('[^']*')/", '/("[^"]*")/'], ["''", '""'], $query);
$statements = array_filter(array_map('trim', explode(';', $cleanQuery)));

if (count($statements) > 1) {
    echo json_encode(['error' => 'Solo se permite un statement por ejecución.']);
    exit;
}

// --- CONEXIÓN ---
$db_host = $_ENV['DB_HOST'] ?? 'localhost';
$db_name = $_ENV['DB_NAME'] ?? 'tutorial_db';
$db_user = $_ENV['DB_USER'] ?? 'root';
$db_pass = $_ENV['DB_PASS'] ?? '';

try {
    $pdo = new PDO(
        "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4",
        $db_user, $db_pass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT            => 5,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET sql_mode='STRICT_TRANS_TABLES'",
        ]
    );
} catch (PDOException $e) {
    echo json_encode([
        'error' => 'No se pudo conectar a la base de datos. ' .
                   'Verificá que XAMPP esté corriendo y que <code>tutorial_db</code> exista.'
    ]);
    exit;
}

// --- DETECTAR TIPO DE QUERY ---
$queryLimpia = trim(preg_replace(['/--[^\n]*/', '/#[^\n]*/'], '', $query));
$firstWord   = strtoupper(strtok($queryLimpia, " \t\n\r"));

$readOnly = ['SELECT', 'SHOW', 'DESCRIBE', 'DESC', 'EXPLAIN'];
$writeOk  = ['INSERT', 'UPDATE', 'DELETE'];

if (!in_array($firstWord, array_merge($readOnly, $writeOk))) {
    echo json_encode([
        'error' => "Comando <strong>$firstWord</strong> no reconocido. " .
                   "Usá SELECT, SHOW, DESCRIBE, INSERT, UPDATE o DELETE."
    ]);
    exit;
}

// --- EJECUTAR ---
try {
    $start = microtime(true);
    $stmt  = $pdo->prepare($query);
    $stmt->execute();
    $elapsed = round((microtime(true) - $start) * 1000, 2);

    if (in_array($firstWord, $readOnly)) {
        $rows    = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $columns = $rows ? array_keys($rows[0]) : [];

        echo json_encode([
            'type'    => 'select',
            'columns' => $columns,
            'rows'    => $rows,
            'count'   => count($rows),
            'time'    => $elapsed,
        ]);

    } else {
        $affected = $stmt->rowCount();
        $lastId   = ($firstWord === 'INSERT') ? $pdo->lastInsertId() : null;

        echo json_encode([
            'type'     => 'write',
            'affected' => $affected,
            'lastId'   => $lastId,
            'time'     => $elapsed,
            'message'  => match($firstWord) {
                'INSERT' => "$affected fila(s) insertada(s). ID generado: $lastId",
                'UPDATE' => "$affected fila(s) actualizada(s).",
                'DELETE' => "$affected fila(s) eliminada(s).",
                default  => "Query ejecutado. $affected fila(s) afectada(s)."
            }
        ]);
    }

} catch (PDOException $e) {
    $msg = $e->getMessage();
    // PDO formato: "SQLSTATE[42S02]: ..." → mostrar solo la parte útil
    if (preg_match('/: (.+)$/', $msg, $matches)) $msg = $matches[1];
    echo json_encode(['error' => 'Error SQL: ' . htmlspecialchars($msg)]);
}