<?php
/**
 * EDITOR SQL — editor_db/index.php
 */

if (!defined('WEB_ROOT')) {
    require_once __DIR__ . '/../config.php';
}

$ejemplo = $_GET['ejemplo'] ?? '';
$ejemplo = preg_replace('/[^a-zA-Z0-9_]/', '', $ejemplo);

$queryInicial = '';
if ($ejemplo) {
    $exampleFile = __DIR__ . '/../ejemplos/' . $ejemplo . '.sql';
    if (file_exists($exampleFile)) {
        $queryInicial = file_get_contents($exampleFile);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editor SQL — MySQL</title>

    <!-- CodeMirror — igual que el editor original -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/dracula.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/eclipse.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/hint/show-hint.min.css">

    <link rel="stylesheet" href="<?php echo asset('editor_db/editor_db.css'); ?>">
</head>
<body data-theme="dark" data-base-url="<?php echo htmlspecialchars(rtrim(WEB_ROOT, '/'), ENT_QUOTES); ?>">

<div class="editor-wrapper">

    <!-- TOOLBAR — idéntico al editor original -->
    <div class="toolbar">
        <div class="toolbar-left">
            <span id="editorStats" class="editor-stats"></span>
        </div>
        <div class="toolbar-right">
            <span class="keyboard-tip">Ctrl+Space</span>
            <div id="resultDimensions" class="result-dimensions"></div>
            <button id="btnTheme" class="btn btn-secondary" title="Cambiar tema"><span class="theme-icon--dark">◑</span></button>
            <button id="btnCopy"  class="btn btn-secondary" title="Copiar código">Copiar</button>
            <button id="btnClear" class="btn btn-secondary" title="Restaurar código original">Restaurar</button>
            <button id="btnRun"   class="btn btn-primary"   title="Ejecutar (Ctrl+Enter)">Ejecutar <span class="shortcut" id="runShortcut">Ctrl+Enter</span></button>
        </div>
    </div>

    <!-- PANELS -->
    <div class="panels">

        <!-- Izquierda: editor + resultado -->
        <div class="panel editor-panel">

            <div class="sql-editor-area" id="sqlEditorArea">
                <textarea id="sqlEditor" autocomplete="off"><?php
                    echo htmlspecialchars($queryInicial, ENT_QUOTES, 'UTF-8');
                ?></textarea>
            </div>

            <!-- Divider vertical arrastrable -->
            <div class="divider-h" id="dividerH"></div>

            <div class="result-panel">
                <div class="result-header">
                    <span class="result-label">RESULTADO</span>
                    <div class="result-meta" id="resultMeta"></div>
                </div>
                <div class="result-body" id="resultBody">
                    <div class="result-placeholder">
                        <svg width="44" height="44" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                            <ellipse cx="12" cy="5" rx="9" ry="3"/>
                            <path d="M3 5v14c0 1.66 4.03 3 9 3s9-1.34 9-3V5"/>
                            <path d="M3 12c0 1.66 4.03 3 9 3s9-1.34 9-3"/>
                        </svg>
                        <p>Escribí un query SQL y hacé clic en <strong>Ejecutar</strong><br>
                        o presioná <kbd>Ctrl</kbd> + <kbd>Enter</kbd></p>
                    </div>
                </div>
            </div>

        </div>

        <!-- Divider -->
        <div class="divider" id="divider"></div>

        <!-- Derecha: explorador BD -->
        <aside class="panel db-explorer" id="dbExplorer">
            <div class="db-explorer-header">
                <div class="db-header-row">
                    <svg class="db-header-icon" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.8" viewBox="0 0 24 24">
                        <ellipse cx="12" cy="5" rx="9" ry="3"/>
                        <path d="M3 5v14c0 1.66 4.03 3 9 3s9-1.34 9-3V5"/>
                        <path d="M3 12c0 1.66 4.03 3 9 3s9-1.34 9-3"/>
                    </svg>
                    <span class="db-name">tutorial_db</span>
                    <span class="db-engine">MySQL</span>
                </div>
            </div>
            <div class="db-section-label">TABLAS</div>
            <div class="db-tables-list" id="tablesList">
                <div class="db-loading">Cargando...</div>
            </div>
        </aside>

    </div>
</div>

<div id="dbToast" class="toast" role="status" aria-live="polite"></div>

<!-- CodeMirror JS — igual que el editor original -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/sql/sql.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/hint/show-hint.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/hint/anyword-hint.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/edit/matchbrackets.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/edit/closebrackets.min.js"></script>

<script src="<?php echo asset('editor_db/editor_db.js'); ?>"></script>

</body>
</html>