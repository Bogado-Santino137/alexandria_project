<?php
/**
 * Tutorial: Variables en Python
 */

$pageTitle = "Variables en Python - Tutorial Interactivo";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="layout-container">
    <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

    <main class="main-content">
<div class="tutorial-container" style="--lang-color: #3776AB">

    <div class="tutorial-intro py">
        <h1>Variables en Python</h1>
        <p>Aprendé a declarar, usar y manipular variables en Python. Las variables son la base de la programación.</p>
    </div>

    <div class="tutorial-section">
        <h2>¿Qué son las Variables?</h2>
        <p>
            Las variables son <strong>contenedores que almacenan datos</strong> en la memoria de tu programa.
            En Python, no necesitás declarar el tipo ni usar símbolos especiales.
        </p>
        <pre><code class="language-python">nombre   = "Juan"
edad     = 25
precio   = 19.99
es_activo = True</code></pre>
        <div class="note-box info">
            <strong>Importante</strong>
            <p>Python detecta automáticamente el tipo de dato. No necesitás escribir <code>int</code>, <code>str</code>, etc.</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Sintaxis Básica</h2>
        <p>Para crear una variable en Python:</p>
        <pre><code class="language-python">nombre_variable = valor</code></pre>
        <p><strong>Reglas:</strong></p>
        <ul>
            <li>Debe empezar con letra o guión bajo <code>_</code></li>
            <li>Puede contener letras, números y guiones bajos</li>
            <li>Es case-sensitive: <code>nombre</code> es diferente a <code>Nombre</code></li>
            <li>Por convención, usá <code>snake_case</code> (todo en minúsculas con guiones bajos)</li>
        </ul>
        <pre><code class="language-python"># Correcto
nombre        = "Ana"
edad_usuario  = 30
_total        = 100

# Incorrecto
2nombre       = "Error"   # No puede empezar con número
precio-total  = 50        # No puede tener guiones (usar guión bajo)
class         = "Python"  # No usar palabras reservadas</code></pre>
        <a href="../editor/index.php?ejemplo=python_01_variables_01" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 1: Variables básicas
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Tipos de Datos</h2>
        <p>Python soporta varios tipos de datos básicos:</p>
        <div class="card-grid">
            <div class="info-card">
                <h4>String (Texto)</h4>
                <code>nombre = "Juan"</code>
            </div>
            <div class="info-card">
                <h4>Integer (Entero)</h4>
                <code>edad = 25</code>
            </div>
            <div class="info-card">
                <h4>Float (Decimal)</h4>
                <code>precio = 19.99</code>
            </div>
            <div class="info-card">
                <h4>Boolean</h4>
                <code>activo = True</code>
            </div>
            <div class="info-card">
                <h4>List (Lista)</h4>
                <code>numeros = [1, 2, 3]</code>
            </div>
            <div class="info-card">
                <h4>None (Nulo)</h4>
                <code>valor = None</code>
            </div>
        </div>
        <div class="note-box tip">
            <strong>type() para ver el tipo</strong>
            <p>Usá <code>print(type(variable))</code> para saber qué tipo de dato es.</p>
        </div>
    </div>

    <div class="tutorial-section">
        <h2>Operaciones Básicas</h2>

        <h3>Concatenación de texto</h3>
        <pre><code class="language-python">nombre   = "Juan"
apellido = "Pérez"
nombre_completo = nombre + " " + apellido
print(nombre_completo)  # Juan Pérez

# f-strings (forma moderna — Python 3.6+)
print(f"Hola, soy {nombre_completo}")</code></pre>
        <a href="../editor/index.php?ejemplo=python_01_variables_02" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 2: Concatenación y f-strings
        </a>

        <h3>Aritmética</h3>
        <pre><code class="language-python">a = 10
b = 5

suma            = a + b    # 15
resta           = a - b    # 5
multiplicacion  = a * b    # 50
division        = a / b    # 2.0
division_entera = a // b   # 2
modulo          = a % b    # 0
potencia        = a ** b   # 100000</code></pre>
        <a href="../editor/index.php?ejemplo=python_01_variables_03" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 3: Operaciones matemáticas
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Ejemplo Completo</h2>
        <p>Calculando el precio final de una compra:</p>
        <pre><code class="language-python">producto  = "Laptop"
precio    = 899.99
descuento = 0.15
cantidad  = 2

precio_con_descuento = precio - (precio * descuento)
total = precio_con_descuento * cantidad

print(f"Producto: {producto}")
print(f"Precio original: ${precio}")
print(f"Descuento: {descuento * 100}%")
print(f"Precio con descuento: ${precio_con_descuento:.2f}")
print(f"Cantidad: {cantidad}")
print(f"Total a pagar: ${total:.2f}")</code></pre>
        <a href="../editor/index.php?ejemplo=python_01_variables_04" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 4: Caso completo
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Buenas Prácticas</h2>
        <ul>
            <li><strong>Usá snake_case:</strong> <code>precio_total</code> en vez de <code>precioTotal</code></li>
            <li><strong>Nombres descriptivos:</strong> <code>precio_total</code> en vez de <code>pt</code></li>
            <li><strong>Constantes en MAYÚSCULAS:</strong> <code>PI = 3.14159</code></li>
            <li><strong>f-strings para formateo:</strong> <code>f"Total: {total}"</code> es más legible que concatenar con <code>+</code></li>
            <li><strong>Inicializá siempre:</strong> dale un valor antes de usar la variable</li>
        </ul>
    </div>

</div>
    </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>