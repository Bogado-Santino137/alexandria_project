<?php
/**
 * EDITOR INTERACTIVO
 * =======================
 * Editor profesional con CodeMirror 5
 * 
 * @version 2.0
 */

$ejemplo = $_GET['ejemplo'] ?? 'php_01_variables';
$ejemplo = preg_replace('/[^a-zA-Z0-9_]/', '', $ejemplo);

// Detectar extensión según el prefijo
if (strpos($ejemplo, 'js_') === 0) {
    $filepath = "../ejemplos/{$ejemplo}.js";
} elseif (strpos($ejemplo, 'python_') === 0) {
    $filepath = "../ejemplos/{$ejemplo}.py";
} elseif (strpos($ejemplo, 'html_') === 0) {
    $filepath = "../ejemplos/{$ejemplo}.html";
} elseif (strpos($ejemplo, 'css_') === 0) {
    $filepath = "../ejemplos/{$ejemplo}.html";
} else {
    $filepath = "../ejemplos/{$ejemplo}.php";
}

// Mapa de títulos para la pestaña
$titulos = [
    'php_01_variables_01' => 'Variables PHP — Ej 1',
    'php_01_variables_02' => 'Variables PHP — Ej 2',
    'php_01_variables_03' => 'Variables PHP — Ej 3',
    'php_01_variables_04' => 'Variables PHP — Ej 4',
    'php_02_strings_01'   => 'Strings PHP — Ej 1',
    'php_02_strings_02'   => 'Strings PHP — Ej 2',
    'php_02_strings_03'   => 'Strings PHP — Ej 3',
    'html_01_basico_01'   => 'HTML Básico — Ej 1',
    'html_01_basico_02'   => 'HTML Básico — Ej 2',
    'html_01_basico_03'   => 'HTML Básico — Ej 3',
    'html_01_basico_04'   => 'HTML Básico — Ej 4',
    'js_01_variables_01'  => 'Variables JS — Ej 1',
    'js_01_variables_02'  => 'Variables JS — Ej 2',
    'js_01_variables_03'  => 'Variables JS — Ej 3',
    'js_01_variables_04'  => 'Variables JS — Ej 4',
    'js_01_variables_05'  => 'Variables JS — Ej 5',
    'python_01_variables_01' => 'Variables Python — Ej 1',
    'python_01_variables_02' => 'Variables Python — Ej 2',
    'python_01_variables_03' => 'Variables Python — Ej 3',
    'python_01_variables_04' => 'Variables Python — Ej 4',
    'css_01_selectores_01'   => 'Selectores CSS — Ej 1',
    'css_01_selectores_02'   => 'Selectores CSS — Ej 2',
    'css_01_selectores_03'   => 'Selectores CSS — Ej 3',
    'css_01_selectores_04'   => 'Selectores CSS — Ej 4',
    'css_02_colores_01'      => 'Colores CSS — Ej 1',
    'css_02_colores_02'      => 'Colores CSS — Ej 2',
    'css_02_colores_03'      => 'Colores CSS — Ej 3',
];
$pageTitle = $titulos[$ejemplo] ?? 'Editor — ' . $ejemplo;

$found = file_exists($filepath);
if ($found) {
    $codigo = file_get_contents($filepath);
    // Wrap JavaScript puro en HTML solo si el archivo no trae su propio HTML
    if (strpos($ejemplo, 'js_') === 0 && stripos(trim($codigo), '<!DOCTYPE') === false) {
        $codigo = "<!DOCTYPE html>\n<html lang=\"es\">\n<head>\n    <meta charset=\"UTF-8\">\n    <title>JavaScript</title>\n</head>\n<body>\n    <script>\n{$codigo}\n    </script>\n</body>\n</html>";
    }
} else {
    $codigo = "<?php\necho 'Ejemplo no encontrado.';\n?>";
}

// Detectar lenguaje para data-lang
if (strpos($ejemplo, 'python_') === 0)     $lang = 'python';
elseif (strpos($ejemplo, 'js_') === 0)     $lang = 'js';
elseif (strpos($ejemplo, 'html_') === 0)   $lang = 'html';
elseif (strpos($ejemplo, 'css_') === 0)    $lang = 'css';
else                                       $lang = 'php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/dracula.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/eclipse.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/hint/show-hint.min.css">
    <link rel="stylesheet" href="editor.css">
</head>
<body data-theme="dark" data-lang="<?php echo $lang; ?>" data-found="<?php echo $found ? '1' : '0'; ?>">
    <div class="editor-wrapper">

        <?php if (!$found): ?>
        <div style="display:flex;align-items:center;justify-content:center;height:100vh;background:#1a1a1a;font-family:'Segoe UI',sans-serif;">
            <div style="text-align:center;color:#d4d4d4;max-width:400px;padding:40px;">
                <div style="font-size:48px;margin-bottom:16px;opacity:.4">404</div>
                <h2 style="margin:0 0 12px;font-size:20px;color:#fff">Ejemplo no encontrado</h2>
                <p style="margin:0 0 24px;color:#888;font-size:14px;line-height:1.6">
                    No existe el archivo <code style="background:#2d2d2d;padding:2px 8px;border-radius:4px;color:#818cf8"><?php echo htmlspecialchars($ejemplo); ?></code>
                </p>
                <a href="javascript:history.back()" style="display:inline-block;background:#4f46e5;color:#fff;padding:8px 20px;border-radius:6px;text-decoration:none;font-size:14px;">Volver</a>
            </div>
        </div>
        <?php else: ?>

        <div class="toolbar">
            <div class="toolbar-left">
                <span id="editorStats" class="editor-stats"></span>
            </div>
            <div class="toolbar-right">
                <span class="keyboard-tip">Ctrl+Space</span>
                <div id="resultDimensions" class="result-dimensions"></div>
                <button id="btnTheme" class="btn btn-secondary" title="Cambiar tema"><span class="theme-icon--dark">◑</span></button>
                <button id="btnCopy"  class="btn btn-secondary" title="Copiar código">Copiar</button>
                <button id="btnClear" class="btn btn-secondary" title="Restaurar código original">Restaurar</button>
                <button id="btnRun"   class="btn btn-primary"   title="Ejecutar (Ctrl+Enter)">Ejecutar <span class="shortcut">Ctrl+Enter</span></button>
            </div>
        </div>

        <div class="panels">
            <div class="panel editor-panel">
                <div class="editor-content">
                    <textarea id="editor" name="editor"><?php echo htmlspecialchars($codigo); ?></textarea>
                </div>
            </div>

            <div class="divider" id="divider"></div>

            <div class="panel result-panel">
                <div class="result-content">
                    <iframe id="resultFrame"></iframe>
                </div>
            </div>
        </div>

    </div>

    <div id="toast" class="toast"></div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/php/php.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/clike/clike.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/xml/xml.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/javascript/javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/css/css.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/python/python.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/htmlmixed/htmlmixed.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/hint/show-hint.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/addon/hint/anyword-hint.min.js"></script>
    <script src="editor.js"></script>

    <?php endif; ?>
</body>
</html>