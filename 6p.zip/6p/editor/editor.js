const LANG_COLORS = { php: '#777BB4', js: '#F7DF1E', python: '#3776AB', html: '#E34F26', css: '#264DE4' };
let editor, hasChanges = false, currentTheme = 'dark', originalCode = '';
const $ = id => document.getElementById(id);
const BTN_RUN_HTML = 'Ejecutar';
const getEjemplo = () => { try { return new URL(location.href).searchParams.get('ejemplo') || 'default'; } catch { return 'default'; } };

/*--------------------------- LENGUAJE ---------------------------*/

function detectLanguage(code) {
    const t = code.trim();
    if (t.startsWith('<?php') || t.includes('<?php')) return 'application/x-httpd-php';
    if (t.startsWith('<!DOCTYPE') || t.startsWith('<html') || /<(div|body|head|p|h[1-6]|span|a)\b/.test(t)) return 'htmlmixed';
    if (/^(import |from |def |class |print\(|if __name__)/.test(t) || /#.*python/i.test(t.split('\n')[0])) return 'python';
    if (/^(const |let |var |function |console\.|document\.|window\.|async |await )/.test(t) || /\/\/.*js/i.test(t.split('\n')[0])) return 'javascript';
    return 'application/x-httpd-php';
}

/*--------------------------- INIT ---------------------------*/

function init() {
    originalCode = $('editor').value;
    const lang   = document.body.dataset.lang || 'php';
    document.body.style.setProperty('--lang-color', LANG_COLORS[lang] ?? '#777BB4');

    const saved     = loadFromStorage();
    const startCode = saved || originalCode;
    hasChanges      = !!(saved && saved !== originalCode);

    editor = CodeMirror.fromTextArea($('editor'), {
        mode: detectLanguage(startCode), theme: 'dracula',
        lineNumbers: true, indentUnit: 4, indentWithTabs: false,
        lineWrapping: false, matchBrackets: true, autoCloseBrackets: true,
        extraKeys: {
            'Ctrl-Space': 'autocomplete',
            'Ctrl-Enter': () => { runCode(); return false; },
            'Cmd-Enter':  () => { runCode(); return false; }
        },
        hintOptions: { completeSingle: false }
    });

    editor.setValue(startCode);
    editor.on('change', () => { checkChanges(); saveToStorage(); });

    loadTheme();
    updateStats();
    showInitialMessage();

    $('btnRun').onclick   = runCode;
    $('btnCopy').onclick  = copyCode;
    $('btnClear').onclick = clearCode;
    $('btnTheme').onclick = toggleTheme;

    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !editor.hasFocus()) {
            e.preventDefault(); runCode();
        }
    });

    setupResize();
    window.addEventListener('resize', updateDimensions);
    new ResizeObserver(updateDimensions).observe($('resultFrame'));
}

/*--------------------------- TEMA ---------------------------*/

function applyTheme(theme) {
    currentTheme = theme;
    document.body.dataset.theme = theme;
    editor.setOption('theme', theme === 'dark' ? 'dracula' : 'eclipse');
    $('btnTheme').innerHTML = theme === 'dark'
        ? '<span class="theme-icon--dark">◑</span>'
        : '<span class="theme-icon--light">◐</span>';
}

function toggleTheme() {
    const next = currentTheme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    localStorage.setItem('editor_theme', next);
}

function loadTheme() {
    const saved = localStorage.getItem('editor_theme');
    if (saved) applyTheme(saved);
}

/*--------------------------- CAMBIOS ---------------------------*/

function checkChanges() {
    const changed = editor.getValue() !== originalCode;
    if (changed !== hasChanges) { hasChanges = changed; updateChangeIndicator(); }
    else updateStats();
}

function updateChangeIndicator() {
    $('editorStats').classList.toggle('changed', hasChanges);
    updateStats();
}

/*--------------------------- STATS ---------------------------*/

function updateStats() {
    $('editorStats').textContent = `${editor.lineCount()} líneas • ${editor.getValue().length} caracteres`;
}

function updateDimensions() {
    const f = $('resultFrame');
    $('resultDimensions').textContent = `${f.clientWidth} x ${f.clientHeight}`;
}

/*--------------------------- MENSAJES IFRAME ---------------------------*/

function writeIframe(html) {
    const doc = $('resultFrame').contentDocument;
    doc.open(); doc.write(html); doc.close();
}

function showInitialMessage() {
    const bg    = currentTheme === 'dark' ? '#1a1a1a' : '#ffffff';
    const color = currentTheme === 'dark' ? '#6b7280' : '#9ca3af';
    writeIframe(`<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:'Inter','Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:${bg}}.message{text-align:center;color:${color}}.message svg{width:48px;height:48px;margin-bottom:16px;opacity:.5}.message p{margin:0;font-size:14px}</style></head><body><div class="message"><svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg><p>Hacé clic en <strong>Ejecutar</strong> para ver el resultado</p></div></body></html>`);
    updateDimensions();
}

function showIframeError(title, msg) {
    const safe = msg.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    writeIframe(`<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:'Segoe UI',sans-serif;background:#1a1a1a;margin:0;padding:16px}.error-box{margin:16px;padding:18px 20px;background:#1e1414;border-left:4px solid #ef4444;border-radius:0 6px 6px 0}.error-box h4{color:#ef4444;font-size:13px;font-weight:600;margin:0 0 8px}.error-box p{color:#fca5a5;font-size:13px;line-height:1.7;margin:0}</style></head><body><div class="error-box"><h4>${title}</h4><p>${safe}</p></div></body></html>`);
}

/*--------------------------- EJECUCIÓN ---------------------------*/

async function runCode() {
    const code = editor.getValue().trim();
    if (!code) { showToast('Escribe código primero', 'error'); return; }

    const btn = $('btnRun');
    btn.disabled  = true;
    btn.innerHTML = '<span class="spin">⚙️</span> Ejecutando...';

    // HTML/CSS — directo al iframe
    if (code.toLowerCase().startsWith('<!doctype') || code.toLowerCase().startsWith('<html')) {
        const BASE_STYLE = '<style>body{background:#fff}</style>';
        const injected = code.replace(/(<head[^>]*>)/i, '$1' + BASE_STYLE);
        $('resultFrame').srcdoc = injected !== code ? injected : BASE_STYLE + code;
        setTimeout(() => { btn.disabled = false; btn.innerHTML = BTN_RUN_HTML; }, 300);
        showToast('Código ejecutado', 'success');
        setTimeout(updateDimensions, 100);
        return;
    }

    // PHP / Python — execute.php
    const lang = editor.getOption('mode') === 'python' ? 'python' : 'php';
    const timeoutId = setTimeout(() => {
        btn.disabled = false; btn.innerHTML = BTN_RUN_HTML;
        showIframeError('Tiempo excedido', 'El código tardó más de 3 segundos.');
        showToast('Timeout: código tardó demasiado', 'error');
    }, 4000);

    try {
        const form = new FormData();
        form.append('code', code);
        form.append('lang', lang);
        const response = await fetch('execute.php', { method: 'POST', body: form });
        clearTimeout(timeoutId);

        if (!response.ok) {
            const msg = `Error ${response.status}: ${response.statusText}`;
            showToast(msg, 'error');
            showIframeError('Error', msg);
            return;
        }

        writeIframe(`<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{background:#fff;margin:8px}</style></head><body>${await response.text()}</body></html>`);
        showToast('Código ejecutado', 'success');
        setTimeout(updateDimensions, 100);
    } catch (e) {
        clearTimeout(timeoutId);
        const msg = e.message === 'Failed to fetch' ? 'Error de conexión con el servidor' : e.message.substring(0, 60);
        showToast(msg, 'error');
        showIframeError('Error', 'No se pudo conectar con execute.php. Verificá que el archivo existe.');
    } finally {
        btn.disabled = false;
        btn.innerHTML = BTN_RUN_HTML;
    }
}

/*--------------------------- UTILIDADES ---------------------------*/

async function copyCode() {
    try { await navigator.clipboard.writeText(editor.getValue()); showToast('Código copiado', 'success'); }
    catch { showToast('Error al copiar', 'error'); }
}

function clearCode() {
    if (!hasChanges) { showToast('No hay cambios para restaurar', 'error'); return; }
    const snapshot = editor.getValue();
    editor.setValue(originalCode);
    hasChanges = false;
    updateChangeIndicator(); updateStats(); showInitialMessage();
    showToastWithUndo('Código restaurado', () => {
        editor.setValue(snapshot);
        hasChanges = true;
        updateChangeIndicator(); updateStats();
    });
}

function showToastWithUndo(msg, onUndo) {
    const t = $('toast');
    t.innerHTML = `${msg} — <span id="toastUndo" style="text-decoration:underline;cursor:pointer;font-weight:600">Deshacer</span>`;
    t.className = 'toast show';
    $('toastUndo').onclick = () => { onUndo(); t.classList.remove('show'); };
    clearTimeout(t._timeout);
    t._timeout = setTimeout(() => t.classList.remove('show'), 4000);
}

function showToast(msg, type = 'success') {
    const t = $('toast');
    t.textContent = msg;
    t.className   = `toast show ${type}`;
    clearTimeout(t._timeout);
    t._timeout = setTimeout(() => t.classList.remove('show'), 3000);
}

function saveToStorage() {
    clearTimeout(saveToStorage._t);
    saveToStorage._t = setTimeout(() => {
        try { localStorage.setItem(`editor_${getEjemplo()}`, editor.getValue()); } catch {}
    }, 500);
}

function loadFromStorage() {
    try { return localStorage.getItem(`editor_${getEjemplo()}`); } catch { return null; }
}

/*--------------------------- RESIZE ---------------------------*/

function setupResize() {
    let isResizing = false;
    const isVertical = () => window.innerWidth <= 768;
    const ep = () => document.querySelector('.editor-panel');
    const rp = () => document.querySelector('.result-panel');

    function resetLayout() {
        if (isVertical()) {
            ep().style.width = rp().style.width = '';
            ep().style.height = rp().style.height = '50%';
        } else {
            ep().style.height = rp().style.height = '';
            ep().style.width = rp().style.width = '50%';
        }
        editor.refresh(); updateDimensions();
    }

    let resizeTimeout;
    window.addEventListener('resize', () => { clearTimeout(resizeTimeout); resizeTimeout = setTimeout(resetLayout, 100); });

    function onStart(e) {
        isResizing = true; e.preventDefault();
        document.body.style.cursor = isVertical() ? 'row-resize' : 'col-resize';
        $('resultFrame').style.pointerEvents = 'none';
    }

    function onMove(clientX, clientY) {
        if (!isResizing) return;
        requestAnimationFrame(() => {
            const w = document.querySelector('.panels').getBoundingClientRect();
            if (isVertical()) {
                const p = Math.min(80, Math.max(20, ((clientY - w.top)  / w.height) * 100));
                ep().style.height = p + '%'; rp().style.height = (100 - p) + '%';
            } else {
                const p = Math.min(80, Math.max(20, ((clientX - w.left) / w.width)  * 100));
                ep().style.width  = p + '%'; rp().style.width  = (100 - p) + '%';
            }
            editor.refresh(); updateDimensions();
        });
    }

    function onEnd() {
        if (!isResizing) return;
        isResizing = false;
        document.body.style.cursor = '';
        $('resultFrame').style.pointerEvents = '';
    }

    let lastMove = 0, lastTouch = 0;
    const throttle = (last, fn) => { const n = Date.now(); if (n - last < 16) return last; fn(); return n; };

    $('divider').onmousedown  = onStart;
    $('divider').ontouchstart = onStart;
    document.onmousemove = (e) => { lastMove  = throttle(lastMove,  () => onMove(e.clientX, e.clientY)); };
    document.ontouchmove = (e) => { if (e.touches[0]) lastTouch = throttle(lastTouch, () => onMove(e.touches[0].clientX, e.touches[0].clientY)); };
    document.onmouseup  = onEnd;
    document.ontouchend = onEnd;
}

/*--------------------------- ARRANQUE ---------------------------*/

document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', init) : init();