<?php
header('Content-Type: text/html; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline';");

// --- Helpers de respuesta ---
function emptyHTML() {
    return '<!DOCTYPE html><html><body><p style="color:#999;font-family:sans-serif;padding:20px">No hay código para ejecutar.</p></body></html>';
}
function errorHTML($msg) {
    return '<!DOCTYPE html><html><body style="background:#1a1a1a;margin:0;padding:16px;font-family:sans-serif"><div style="margin:16px;padding:18px 20px;background:#1e1414;border-left:4px solid #ef4444;border-radius:0 6px 6px 0"><strong style="color:#ef4444;font-size:13px;font-weight:600;display:block;margin-bottom:8px">Error de Seguridad:</strong><span style="color:#fca5a5;font-size:13px;line-height:1.7">' . $msg . '</span></div></body></html>';
}
function warningHTML($msg) {
    return '<!DOCTYPE html><html><body style="background:#1a1a1a;margin:0;padding:16px;font-family:sans-serif"><div style="margin:16px;padding:18px 20px;background:#1e1a10;border-left:4px solid #f59e0b;border-radius:0 6px 6px 0"><strong style="color:#f59e0b;font-size:13px;font-weight:600;display:block;margin-bottom:8px">Advertencia:</strong><span style="color:#fcd34d;font-size:13px;line-height:1.7">' . htmlspecialchars($msg) . '</span></div></body></html>';
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); die('Method Not Allowed'); }
if (empty($_POST['code']))                 { echo emptyHTML(); exit; }
if (strlen($_POST['code']) > 50000)        { http_response_code(413); echo errorHTML('Código demasiado largo (máx 50KB)'); exit; }

$code = $_POST['code'];
$lang = $_POST['lang'] ?? 'php';

// ============================================================
// PYTHON
// ============================================================
if ($lang === 'python') {

    $pyForbidden = [
        '/\bimport\s+os\b/i'                => 'import os',
        '/\bimport\s+sys\b/i'               => 'import sys',
        '/\bimport\s+subprocess\b/i'        => 'import subprocess',
        '/\bimport\s+shutil\b/i'            => 'import shutil',
        '/\bimport\s+socket\b/i'            => 'import socket',
        '/\bimport\s+urllib\b/i'            => 'import urllib',
        '/\bimport\s+requests\b/i'          => 'import requests',
        '/\bimport\s+ftplib\b/i'            => 'import ftplib',
        '/\bimport\s+smtplib\b/i'           => 'import smtplib',
        '/\bimport\s+ctypes\b/i'            => 'import ctypes',
        '/\bimport\s+pickle\b/i'            => 'import pickle',
        '/\b__import__\s*\(/i'              => '__import__()',
        '/\beval\s*\(/i'                    => 'eval()',
        '/\bexec\s*\(/i'                    => 'exec()',
        '/\bcompile\s*\(/i'                 => 'compile()',
        '/\bopen\s*\(/i'                    => 'open() — acceso a archivos',
        '/\bgetattr\s*\(/i'                 => 'getattr()',
        '/\bsetattr\s*\(/i'                 => 'setattr()',
        '/\b__builtins__\b/i'               => '__builtins__',
        '/\bglobals\s*\(\s*\)/i'            => 'globals()',
        '/\blocals\s*\(\s*\)/i'             => 'locals()',
        '/\b(while\s+True|while\s+1)\s*:/i' => 'Loop infinito: while True',
    ];

    foreach ($pyForbidden as $pattern => $desc) {
        if (preg_match($pattern, $code)) { echo errorHTML("Código no permitido: <code>$desc</code>"); exit; }
    }

    $tmpDir = sys_get_temp_dir() . '/py_editor/';
    if (!is_dir($tmpDir)) mkdir($tmpDir, 0700, true);
    foreach (glob($tmpDir . '*.py') as $f) {
        if (is_file($f) && (time() - filemtime($f)) > 3600) @unlink($f);
    }

    $tmpFile = tempnam($tmpDir, 'code_') . '.py';
    file_put_contents($tmpFile, $code);
    chmod($tmpFile, 0600);

    $isWindows = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
    $pyPath    = $_ENV['PYTHON_PATH'] ?? ($isWindows ? 'py' : 'python3');

    if (!function_exists('shell_exec') || in_array('shell_exec', array_map('trim', explode(',', ini_get('disable_functions'))))) {
        echo warningHTML('Python no está disponible en este entorno de ejecución.');
        exit;
    }

    $cmd = $isWindows
        ? escapeshellarg($pyPath) . ' -X utf8 ' . escapeshellarg($tmpFile) . ' 2>&1'
        : 'timeout 5 ' . escapeshellarg($pyPath) . ' -u ' . escapeshellarg($tmpFile) . ' 2>&1';

    $output = shell_exec($cmd);
    @unlink($tmpFile);

    if ($output === null) { echo warningHTML('Timeout: El código tardó más de 5 segundos.'); exit; }

    $output  = str_replace($tmpFile, 'script.py', $output);
    $isError = (bool) preg_match('/\b(Error|Traceback|SyntaxError|NameError|TypeError|ValueError|IndentationError|AttributeError|KeyError|IndexError)\b/', $output);

    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>';
    echo 'body{padding:20px;margin:0;line-height:1.8}';
    echo 'pre{margin:0;font-size:14px;line-height:1.8;white-space:pre-wrap;word-break:break-word;font-family:\'Consolas\',\'Monaco\',monospace}';
    echo '.error-box{background:#1e1414;border-left:4px solid #ef4444;padding:15px;border-radius:0 6px 6px 0}';
    echo '.error-box pre{color:#fca5a5}';
    echo '</style></head><body>';
    echo $isError
        ? '<div class="error-box"><strong>Error:</strong><pre>' . htmlspecialchars($output) . '</pre></div>'
        : '<pre>' . htmlspecialchars($output) . '</pre>';
    echo '</body></html>';
    exit;
}

// ============================================================
// PHP
// ============================================================

$forbidden = [
    'exec','shell_exec','system','passthru','popen','proc_open','pcntl_exec','pcntl_fork','pcntl_signal',
    'eval','assert','create_function',
    'file_put_contents','fopen','fwrite','fputs','unlink','rmdir','mkdir','rename','copy','chmod','chown','chgrp',
    'file_get_contents','readfile','fread','fgets','file',
    'include','include_once','require','require_once',
    'call_user_func','call_user_func_array','array_map','array_filter','usort','uasort','array_reduce',
    'ReflectionFunction','ReflectionMethod','ReflectionClass',
    'fsockopen','pfsockopen','socket_create','socket_connect','curl_exec','curl_init','stream_socket_client',
    'mysqli_connect','mysql_connect','pg_connect','PDO',
    'dl','ini_set','ini_alter','putenv','set_time_limit','ignore_user_abort','header','setcookie','session_start',
];

foreach ($forbidden as $fn) {
    if (preg_match('/\b' . preg_quote($fn, '/') . '\s*\(/i', $code)) {
        echo errorHTML("Función prohibida: <code>{$fn}()</code>"); exit;
    }
}

foreach (['_GET','_POST','_REQUEST','_SERVER','_COOKIE','_SESSION','_FILES','_ENV','GLOBALS'] as $var) {
    if (preg_match('/\$' . $var . '\b/i', $code)) {
        echo errorHTML("Variable superglobal prohibida: <code>\${$var}</code>"); exit;
    }
}

$patterns = [
    '/\$\$/'                  => 'Variables variables ($$var)',
    '/\${[^}]+}/'             => 'Variables complejas (${...})',
    '/@\$/'                   => 'Supresión de errores (@$)',
    '/`[^`]+`/'               => 'Backticks (shell)',
    '/\\\\x[0-9a-f]{2}/i'     => 'Caracteres hex sospechosos',
    '/\bbase64_decode\s*\(/i' => 'base64_decode()',
    '/\bstr_rot13\s*\(/i'     => 'str_rot13()',
    '/\bgzinflate\s*\(/i'     => 'gzinflate()',
    '/\bpack\s*\(/i'          => 'pack()',
    '/\bdie\s*[(\;]/i'        => 'die() no permitido',
    '/\bexit\s*[(\;]/i'       => 'exit() no permitido',
];

foreach ($patterns as $pattern => $desc) {
    if (preg_match($pattern, $code)) { echo errorHTML("Patrón peligroso: $desc"); exit; }
}

$clean = preg_replace(['/\/\*.*?\*\//s', '/\/\/.*$/m'], '', $code);
if (preg_match('/for\s*\([^;]*;\s*[^;]*[<>=!]+\s*(\d+)\s*;/i', $clean, $m) && (int)$m[1] > 10000)
    { echo warningHTML('Loop con más de 10.000 iteraciones'); exit; }
if (preg_match('/while\s*\(\s*(true|1)\s*\)/i', $clean))
    { echo warningHTML('Loop infinito: while(true)'); exit; }
if (preg_match('/do\s*\{.*?\}\s*while\s*\(\s*(true|1)\s*\)/is', $clean))
    { echo warningHTML('Loop infinito: do...while(true)'); exit; }
if (preg_match('/for\s*\([^;]*;\s*;\s*[^)]*\)/i', $clean))
    { echo warningHTML('Loop infinito: for sin condición'); exit; }

set_time_limit(3);
ini_set('memory_limit', '32M');
ini_set('disable_functions', implode(',', $forbidden));

$tmpDir = sys_get_temp_dir() . '/php_editor/';
if (!is_dir($tmpDir)) mkdir($tmpDir, 0700, true);
foreach (glob($tmpDir . '*') as $f) {
    if (is_file($f) && (time() - filemtime($f)) > 3600) @unlink($f);
}

$tmpFile = tempnam($tmpDir, 'code_');
chmod($tmpFile, 0600);
file_put_contents($tmpFile, $code);

ini_set('display_errors', 1);
error_reporting(E_ALL);
set_error_handler(fn($s, $msg, $f, $l) => throw new ErrorException($msg, 0, $s, $f, $l));
ob_start();

echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>';
echo 'body{margin:8px}';
echo '.error{background:#1e1414;border-left:4px solid #ef4444;padding:15px;margin:10px 0;border-radius:0 6px 6px 0;color:#fca5a5}';
echo '.warning{background:#1e1a10;border-left:4px solid #f59e0b;padding:15px;margin:10px 0;border-radius:0 6px 6px 0;color:#fcd34d}';
echo 'code{background:#f3f4f6;padding:2px 6px;border-radius:3px;font-family:monospace}';
echo '</style></head><body>';

$start = microtime(true);

try {
    include $tmpFile;
} catch (ParseError $e) {
    ob_clean();
    echo '<div class="error"><strong>Error de Sintaxis:</strong><br>' . htmlspecialchars($e->getMessage()) . '<br><small>Línea: ' . $e->getLine() . '</small></div>';
} catch (ErrorException $e) {
    ob_clean();
    echo '<div class="warning"><strong>Warning:</strong><br>' . htmlspecialchars($e->getMessage()) . '<br><small>Línea: ' . $e->getLine() . '</small></div>';
} catch (Throwable $e) {
    ob_clean();
    $msg     = $e->getMessage();
    $elapsed = microtime(true) - $start;
    if (str_contains($msg, 'Maximum execution time') || $elapsed >= 3) {
        echo '<div class="warning"><strong>Timeout:</strong> El código tardó más de 3 segundos.</div>';
    } elseif (str_contains($msg, 'Allowed memory size')) {
        echo '<div class="warning"><strong>Memoria agotada:</strong> El código usó más de 32MB.</div>';
    } else {
        echo '<div class="error"><strong>Error:</strong><br>' . htmlspecialchars($msg) . '<br><small>Línea: ' . $e->getLine() . '</small></div>';
    }
}

echo '</body></html>';
$out = ob_get_clean();
echo preg_replace('/<script\b[^>]*>.*?<\/script>/is', '', $out);
if (file_exists($tmpFile)) unlink($tmpFile);
restore_error_handler();