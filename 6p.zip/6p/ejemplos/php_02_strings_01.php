<?php
// Strings en PHP - Ejemplo 1: Básico
// ===================================

$texto1 = "Hola";
$texto2 = "Mundo";

$saludo = $texto1 . " " . $texto2;
echo $saludo;

echo "<br><br>";

$nombre = "Ana";
echo "Mi nombre es $nombre";

echo "<br><br>";

// Comillas simples vs dobles
echo "Con dobles: $nombre<br>";
echo 'Con simples: $nombre<br>';
?>
