<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Variables básicas</title>
</head>
<body>

  <p id="linea1"></p>
  <p id="linea2"></p>
  <p id="linea3"></p>

  <script>
    // Variables en JavaScript - Ejemplo 1: Básico
    let nombre = "Juan";
    let edad   = 25;
    let precio = 19.99;

    document.getElementById("linea1").innerHTML = "Hola, mi nombre es " + nombre;
    document.getElementById("linea2").innerHTML = "Tengo " + edad + " años";
    document.getElementById("linea3").innerHTML = "El precio es: $" + precio;
  </script>

</body>
</html>
