<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Aritmética</title>
</head>
<body>

  <p id="resultado"></p>

  <script>
    // Variables en JavaScript - Ejemplo 4: Aritmética
    let a = 10;
    let b = 3;

    let suma      = a + b;
    let resta     = a - b;
    let multi     = a * b;
    let division  = a / b;
    let resto     = a % b;
    let potencia  = a ** b;

    document.getElementById("resultado").innerHTML =
        `${a} + ${b} = ${suma} | ` +
        `${a} - ${b} = ${resta} | ` +
        `${a} * ${b} = ${multi} | ` +
        `${a} / ${b} = ${division.toFixed(2)} | ` +
        `${a} % ${b} = ${resto} | ` +
        `${a} ** ${b} = ${potencia}`;
  </script>

</body>
</html>
