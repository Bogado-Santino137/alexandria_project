# Variables en Python - Ejemplo 2: Concatenación
# ================================================

nombre = "Juan"
apellido = "Pérez"
nombre_completo = nombre + " " + apellido

print(f"Nombre completo: {nombre_completo}")
print()

# f-strings (forma moderna)
print(f"Hola, soy {nombre_completo}")
print()

# Concatenación tradicional
saludo = "Buenos días"
saludo += f", {nombre_completo}"
print(saludo)
