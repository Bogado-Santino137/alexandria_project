<?php
// Variables en PHP - Ejemplo 1: Básico
// =====================================
// Una variable es un contenedor que almacena un valor

$nombre = "Juan";
$edad = 25;
$precio = 19.99;

echo "Hola, mi nombre es " . $nombre;
echo "<br>";
echo "Tengo " . $edad . " años";
echo "<br>";
echo "El precio es: $" . $precio;
?>
