<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Concatenación y aritmética</title>
</head>
<body>

  <p id="res1"></p>
  <p id="res2"></p>
  <hr>
  <p id="res3"></p>

  <script>
    // Ejemplo 3: Concatenación y template literals
    let nombre = "Carlos";
    let edad   = 30;

    document.getElementById("res1").innerHTML = "Hola " + nombre + ", tenés " + edad + " años";
    document.getElementById("res2").innerHTML = `Hola ${nombre}, tenés ${edad} años`;

    // Aritmética
    let a = 10, b = 3;
    document.getElementById("res3").innerHTML =
        `${a}+${b}=${a+b} | ${a}-${b}=${a-b} | ${a}*${b}=${a*b} | ${a}/${b}=${(a/b).toFixed(2)} | ${a}%${b}=${a%b} | ${a}**${b}=${a**b}`;
  </script>

</body>
</html>
