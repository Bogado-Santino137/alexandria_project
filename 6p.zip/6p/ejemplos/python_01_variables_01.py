# Variables en Python - Ejemplo 1: Básico
# =========================================
# Una variable es un contenedor que almacena un valor

nombre = "Juan"
edad = 25
precio = 19.99

print(f"Hola, mi nombre es {nombre}")
print(f"Tengo {edad} años")
print(f"El precio es: ${precio}")
