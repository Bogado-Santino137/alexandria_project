<?php
// Variables en PHP - Ejemplo 2: Concatenación
// ============================================

$nombre = "Juan";
$apellido = "Pérez";
$nombreCompleto = $nombre . " " . $apellido;

echo "Nombre completo: " . $nombreCompleto;
echo "<br><br>";

// También podés usar variables dentro de comillas dobles
echo "Hola, soy $nombreCompleto";
echo "<br><br>";

// Concatenar y asignar
$saludo = "Buenos días";
$saludo .= ", $nombreCompleto";
echo $saludo;
?>
