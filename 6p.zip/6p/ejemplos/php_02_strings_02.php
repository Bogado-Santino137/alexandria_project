<?php
// Strings en PHP - Ejemplo 2: Funciones Útiles
// =============================================

$frase = "Aguante PHP";

echo "Original: " . $frase . "<br>";
echo "Mayúsculas: " . strtoupper($frase) . "<br>";
echo "Minúsculas: " . strtolower($frase) . "<br>";
echo "Longitud: " . strlen($frase) . " caracteres<br>";
echo "Primera letra mayúscula: " . ucfirst(strtolower($frase)) . "<br>";
?>
