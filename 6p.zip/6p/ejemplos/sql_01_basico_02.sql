-- Ejemplo 2: WHERE + ORDER BY
-- ============================
-- Productos con precio mayor a $50, ordenados de mayor a menor

SELECT nombre, precio, stock
FROM productos
WHERE precio > 50
ORDER BY precio DESC;
