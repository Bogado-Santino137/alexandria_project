<?php
// Variables en PHP - Ejemplo 4: Caso Completo
// ============================================
// Calculando el precio final de una compra

$producto = "Laptop";
$precio = 899.99;
$descuento = 0.15;
$cantidad = 2;

$precioConDescuento = $precio - ($precio * $descuento);
$total = $precioConDescuento * $cantidad;

echo "<h3>Resumen de Compra</h3>";
echo "Producto: $producto<br>";
echo "Precio original: $" . $precio . "<br>";
echo "Descuento: " . ($descuento * 100) . "%<br>";
echo "Precio con descuento: $" . number_format($precioConDescuento, 2) . "<br>";
echo "Cantidad: $cantidad<br>";
echo "<strong>Total a pagar: $" . number_format($total, 2) . "</strong>";
?>
