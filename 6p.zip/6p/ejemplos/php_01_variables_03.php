<?php
// Variables en PHP - Ejemplo 3: Operaciones Matemáticas
// ======================================================

$a = 10;
$b = 5;

$suma = $a + $b;
$resta = $a - $b;
$multiplicacion = $a * $b;
$division = $a / $b;

echo "a = $a, b = $b<br><br>";
echo "Suma: $a + $b = $suma<br>";
echo "Resta: $a - $b = $resta<br>";
echo "Multiplicación: $a × $b = $multiplicacion<br>";
echo "División: $a ÷ $b = $division<br>";
?>
