<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>let, const y var</title>
</head>
<body>

  <p id="res1"></p>
  <p id="res2"></p>
  <p id="res3"></p>

  <script>
    // Variables en JavaScript - Ejemplo 2: let, const, var
    const nombre = "Ana";        // No cambia
    let   edad   = 20;           // Puede cambiar
    let   pais   = "Argentina";

    document.getElementById("res1").innerHTML = "Nombre: " + nombre;
    document.getElementById("res2").innerHTML = "Edad: " + edad;

    // Reasignación con let
    edad = 21;
    pais = "Brasil";
    document.getElementById("res3").innerHTML = "Edad actualizada: " + edad + " — País: " + pais;
  </script>

</body>
</html>
