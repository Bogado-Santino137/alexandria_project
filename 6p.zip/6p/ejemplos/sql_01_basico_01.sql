-- Ejemplo 1: SELECT Básico
-- ========================
-- Consultá todos los clientes de la tienda

SELECT * FROM clientes;
