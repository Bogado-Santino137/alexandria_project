-- Ejemplo 3: JOIN
-- ================
-- Órdenes con el nombre del cliente y su estado

SELECT 
    o.id            AS nro_orden,
    c.nombre        AS cliente,
    c.ciudad,
    o.fecha,
    o.estado,
    o.total
FROM ordenes o
JOIN clientes c ON o.id_cliente = c.id
ORDER BY o.fecha DESC;
