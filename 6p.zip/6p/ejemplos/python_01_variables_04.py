# Variables en Python - Ejemplo 4: Caso Completo
# ================================================
# Calculando el precio final de una compra

producto = "Laptop"
precio = 899.99
descuento = 0.15
cantidad = 2

precio_con_descuento = precio - (precio * descuento)
total = precio_con_descuento * cantidad

print("=" * 40)
print("RESUMEN DE COMPRA")
print("=" * 40)
print(f"Producto: {producto}")
print(f"Precio original: ${precio}")
print(f"Descuento: {descuento * 100}%")
print(f"Precio con descuento: ${precio_con_descuento:.2f}")
print(f"Cantidad: {cantidad}")
print("=" * 40)
print(f"TOTAL A PAGAR: ${total:.2f}")
print("=" * 40)
