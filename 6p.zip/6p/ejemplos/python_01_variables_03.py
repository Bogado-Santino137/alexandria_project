# Variables en Python - Ejemplo 3: Operaciones Matemáticas
# ==========================================================

a = 10
b = 5

suma = a + b
resta = a - b
multiplicacion = a * b
division = a / b

print(f"a = {a}, b = {b}")
print()
print(f"Suma: {a} + {b} = {suma}")
print(f"Resta: {a} - {b} = {resta}")
print(f"Multiplicación: {a} × {b} = {multiplicacion}")
print(f"División: {a} ÷ {b} = {division}")
