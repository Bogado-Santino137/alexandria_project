<?php
// Strings en PHP - Ejemplo 3: Caso Completo
// ==========================================

$texto = "  PHP es GENIAL para desarrollo web  ";

$textoLimpio = trim($texto);
$longitud = strlen($textoLimpio);
$minusculas = strtolower($textoLimpio);
$mayusculas = strtoupper($textoLimpio);
$reemplazo = str_replace("GENIAL", "excelente", $textoLimpio);
$capitalizado = ucfirst(strtolower($textoLimpio));

echo "Original: '$texto'<br><br>";
echo "Limpio: '$textoLimpio'<br>";
echo "Longitud: $longitud caracteres<br>";
echo "Minúsculas: $minusculas<br>";
echo "Mayúsculas: $mayusculas<br>";
echo "Reemplazo: $reemplazo<br>";
echo "Capitalizado: $capitalizado<br>";
?>
