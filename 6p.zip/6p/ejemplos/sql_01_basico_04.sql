-- Ejemplo 4: GROUP BY + Funciones de Agregación
-- ===============================================
-- Valor total del inventario por categoría

SELECT 
    c.nombre                        AS categoria,
    COUNT(p.id)                     AS cantidad_productos,
    SUM(p.stock)                    AS unidades_en_stock,
    ROUND(AVG(p.precio), 2)         AS precio_promedio,
    ROUND(SUM(p.precio * p.stock), 2) AS valor_inventario
FROM productos p
JOIN categorias c ON p.id_categoria = c.id
GROUP BY c.id, c.nombre
ORDER BY valor_inventario DESC;
