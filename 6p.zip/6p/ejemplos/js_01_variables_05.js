<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Caso completo</title>
</head>
<body>

  <h3>Resumen de Compra</h3>
  <p>Producto: <strong id="producto"></strong></p>
  <p>Precio original: <strong id="original"></strong></p>
  <p>Descuento: <strong id="dcto"></strong></p>
  <p>Precio con descuento: <strong id="final"></strong></p>
  <p>Cantidad: <strong id="cantidad"></strong></p>
  <p>Total a pagar: <strong id="total"></strong></p>

  <script>
    // Variables en JavaScript - Ejemplo 5: Caso Completo
    const producto  = "Laptop";
    const precio    = 899.99;
    const descuento = 0.15;
    const cantidad  = 2;

    let precioConDescuento = precio - (precio * descuento);
    let total              = precioConDescuento * cantidad;

    document.getElementById("producto").innerHTML = producto;
    document.getElementById("original").innerHTML = "$" + precio;
    document.getElementById("dcto").innerHTML     = (descuento * 100) + "%";
    document.getElementById("final").innerHTML    = "$" + precioConDescuento.toFixed(2);
    document.getElementById("cantidad").innerHTML = cantidad;
    document.getElementById("total").innerHTML    = "$" + total.toFixed(2);
  </script>

</body>
</html>
