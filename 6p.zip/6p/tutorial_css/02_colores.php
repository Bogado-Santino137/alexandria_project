<?php
/**
 * Tutorial: Colores y Fondos en CSS
 */

$pageTitle = "Colores y Fondos CSS - Tutorial Interactivo";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="layout-container">
    <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

    <main class="main-content">
<div class="tutorial-container" style="--lang-color: #264DE4">

    <div class="tutorial-intro css">
        <h1>Colores y Fondos en CSS</h1>
        <p>Aprendé las distintas formas de definir colores y aplicar fondos a los elementos HTML.</p>
    </div>

    <div class="tutorial-section">
        <h2>Formas de Definir Colores</h2>
        <p>CSS permite definir colores de varias maneras. Todas son válidas — elegí la que te resulte más cómoda.</p>
        <pre><code class="language-css">/* Por nombre */
color: red;
color: blue;
color: tomato;

/* Hexadecimal — el más usado */
color: #ff0000;   /* rojo */
color: #264DE4;   /* azul CSS */
color: #333;      /* forma corta: equivale a #333333 */

/* RGB */
color: rgb(255, 0, 0);       /* rojo */
color: rgb(38, 77, 228);     /* azul */

/* RGBA — con transparencia (0 = transparente, 1 = sólido) */
color: rgba(0, 0, 0, 0.5);   /* negro al 50% */</code></pre>
        <div class="note-box info">
            <strong>¿Cuál usar?</strong>
            <p>El formato <strong>hexadecimal</strong> es el más común en la web. RGBA es útil cuando necesitás transparencia.</p>
        </div>
        <a href="../editor/index.php?ejemplo=css_02_colores_01" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 1: Formas de definir colores
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Color de Texto y Fondo</h2>
        <p>Las dos propiedades de color más usadas son <code>color</code> para el texto y <code>background-color</code> para el fondo.</p>
        <pre><code class="language-css">/* Color del texto */
p {
    color: #1f2937;
}

/* Color de fondo del elemento */
.alerta {
    background-color: #fef3c7;
    color: #92400e;
}

.exito {
    background-color: #d1fae5;
    color: #065f46;
}

.error {
    background-color: #fee2e2;
    color: #991b1b;
}</code></pre>
        <div class="note-box tip">
            <strong>Contraste</strong>
            <p>Siempre asegurate de que haya suficiente contraste entre el texto y el fondo. Un texto claro sobre fondo claro es difícil de leer.</p>
        </div>
        <a href="../editor/index.php?ejemplo=css_02_colores_02" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 2: Color de texto y fondo
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Gradientes</h2>
        <p>
            Los gradientes son fondos que transicionan de un color a otro.
            Se aplican con <code>background</code> usando la función <code>linear-gradient()</code>.
        </p>
        <pre><code class="language-css">/* Gradiente lineal — de izquierda a derecha */
.degradado-horizontal {
    background: linear-gradient(to right, #667eea, #764ba2);
}

/* Gradiente lineal — de arriba a abajo */
.degradado-vertical {
    background: linear-gradient(to bottom, #f093fb, #f5576c);
}

/* Gradiente con ángulo */
.degradado-angulo {
    background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
}

/* Gradiente con más de dos colores */
.arcoiris {
    background: linear-gradient(to right, red, orange, yellow, green, blue, violet);
}</code></pre>
        <div class="note-box warning">
            <strong>background vs background-color</strong>
            <p><code>background-color</code> acepta solo colores sólidos. Para gradientes necesitás usar <code>background</code> o <code>background-image</code>.</p>
        </div>
        <a href="../editor/index.php?ejemplo=css_02_colores_03" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 3: Gradientes
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Buenas Prácticas</h2>
        <ul>
            <li><strong>Usá variables CSS para colores:</strong> <code>--color-primario: #264DE4</code> facilita el mantenimiento</li>
            <li><strong>Revisá el contraste:</strong> mínimo 4.5:1 entre texto y fondo para accesibilidad</li>
            <li><strong>Limitá la paleta:</strong> 2 o 3 colores principales dan coherencia visual</li>
            <li><strong>Hex para colores fijos, RGBA para transparencias</strong></li>
            <li><strong>Herramientas útiles:</strong> coolors.co para paletas, contrast checker para accesibilidad</li>
        </ul>
    </div>

</div>
    </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
