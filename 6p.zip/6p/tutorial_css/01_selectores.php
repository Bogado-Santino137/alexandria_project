<?php
/**
 * Tutorial: Selectores CSS
 */

$pageTitle = "Selectores CSS - Tutorial Interactivo";
require_once __DIR__ . '/../includes/header.php';
?>

<div class="layout-container">
    <?php require_once __DIR__ . '/../includes/sidebar.php'; ?>

    <main class="main-content">
<div class="tutorial-container" style="--lang-color: #264DE4">

    <div class="tutorial-intro css">
        <h1>Selectores CSS</h1>
        <p>Aprendé a seleccionar elementos HTML para aplicarles estilos. Los selectores son la base de CSS.</p>
    </div>

    <div class="tutorial-section">
        <h2>¿Qué es CSS?</h2>
        <p>
            <strong>CSS (Cascading Style Sheets)</strong> es el lenguaje que controla la apariencia visual de las páginas web.
            Mientras HTML define la estructura, CSS define cómo se ve: colores, tamaños, posiciones, fuentes y más.
        </p>
        <pre><code class="language-css">/* Sintaxis básica */
selector {
    propiedad: valor;
}</code></pre>
        <div class="note-box info">
            <strong>¿Cómo funciona?</strong>
            <p>CSS se escribe dentro de una etiqueta <code>&lt;style&gt;</code> en el <code>&lt;head&gt;</code>, o en un archivo externo <code>.css</code>. En estos ejemplos lo vamos a escribir dentro del HTML.</p>
        </div>
        <a href="../editor/index.php?ejemplo=css_01_selectores_01" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 1: Mi primer estilo
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Selector de Etiqueta</h2>
        <p>Selecciona <strong>todos</strong> los elementos de ese tipo en la página.</p>
        <pre><code class="language-css">/* Aplica a todos los párrafos */
p {
    color: blue;
    font-size: 16px;
}

/* Aplica a todos los h1 */
h1 {
    color: red;
}</code></pre>
        <div class="note-box warning">
            <strong>Cuidado</strong>
            <p>El selector de etiqueta afecta a <em>todos</em> los elementos de ese tipo. Si querés aplicar estilos solo a algunos, usá clases.</p>
        </div>
        <a href="../editor/index.php?ejemplo=css_01_selectores_02" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 2: Selector de etiqueta
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Selector de Clase</h2>
        <p>
            Las clases se definen con un punto <code>.</code> en CSS y con el atributo <code>class</code> en HTML.
            Podés aplicar la misma clase a múltiples elementos.
        </p>
        <pre><code class="language-css">/* CSS */
.destacado {
    background-color: yellow;
    font-weight: bold;
}

.error {
    color: red;
    border: 1px solid red;
}</code></pre>
        <pre><code class="language-markup">&lt;!-- HTML --&gt;
&lt;p class="destacado"&gt;Este párrafo está destacado.&lt;/p&gt;
&lt;p class="error"&gt;Este párrafo tiene error.&lt;/p&gt;
&lt;p&gt;Este párrafo es normal.&lt;/p&gt;</code></pre>
        <div class="note-box tip">
            <strong>Múltiples clases</strong>
            <p>Un elemento puede tener más de una clase: <code>&lt;p class="destacado error"&gt;</code></p>
        </div>
        <a href="../editor/index.php?ejemplo=css_01_selectores_03" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 3: Selectores de clase
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Selector de ID</h2>
        <p>
            Los IDs se definen con <code>#</code> en CSS y con el atributo <code>id</code> en HTML.
            A diferencia de las clases, un ID debe ser <strong>único</strong> en toda la página.
        </p>
        <pre><code class="language-css">/* CSS */
#titulo-principal {
    font-size: 32px;
    text-align: center;
    color: #333;
}

#pie-pagina {
    background-color: #333;
    color: white;
    padding: 20px;
}</code></pre>
        <pre><code class="language-markup">&lt;!-- HTML --&gt;
&lt;h1 id="titulo-principal"&gt;Mi Título&lt;/h1&gt;
&lt;footer id="pie-pagina"&gt;© 2026&lt;/footer&gt;</code></pre>
        <table class="syntax-table">
            <thead>
                <tr>
                    <th>Selector</th>
                    <th>Sintaxis CSS</th>
                    <th>Sintaxis HTML</th>
                    <th>Unicidad</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Etiqueta</td>
                    <td><code>p { }</code></td>
                    <td><code>&lt;p&gt;</code></td>
                    <td>Todos los elementos</td>
                </tr>
                <tr>
                    <td>Clase</td>
                    <td><code>.nombre { }</code></td>
                    <td><code>class="nombre"</code></td>
                    <td>Reutilizable</td>
                </tr>
                <tr>
                    <td>ID</td>
                    <td><code>#nombre { }</code></td>
                    <td><code>id="nombre"</code></td>
                    <td>Único por página</td>
                </tr>
            </tbody>
        </table>
        <a href="../editor/index.php?ejemplo=css_01_selectores_04" class="btn-try-it" target="_blank" rel="noopener noreferrer">
            Probá el Ejemplo 4: Caso completo
        </a>
    </div>

    <div class="tutorial-section">
        <h2>Buenas Prácticas</h2>
        <ul>
            <li><strong>Preferí clases sobre IDs:</strong> son más flexibles y reutilizables</li>
            <li><strong>Nombres descriptivos:</strong> <code>.btn-principal</code> en vez de <code>.azul</code></li>
            <li><strong>Un ID por elemento:</strong> nunca repitas el mismo ID en la página</li>
            <li><strong>Minúsculas con guiones:</strong> <code>.mi-clase</code> es la convención estándar</li>
            <li><strong>Evitá estilos en línea:</strong> <code>style="color:red"</code> es difícil de mantener</li>
        </ul>
    </div>

</div>
    </main>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
