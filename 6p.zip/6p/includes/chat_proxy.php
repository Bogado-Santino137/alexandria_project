<?php
/**
 * CHAT PROXY — Intermediario seguro para la API de Groq
 * ======================================================
 * La API key vive en .env, nunca en el código.
 *
 * Ubicación: includes/chat_proxy.php
 */

// Cargar variables de entorno desde .env
require_once __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();
$dotenv->required(['GROQ_API_KEY', 'GROQ_MODEL'])->notEmpty();

define('GROQ_API_KEY', $_ENV['GROQ_API_KEY']);
define('GROQ_MODEL',   $_ENV['GROQ_MODEL']);
define('GROQ_URL',     'https://api.groq.com/openai/v1/chat/completions');
define('MAX_TOKENS',   1500);

header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// ── Verificar mismo origen (CSRF básico) ──
// fetch() desde mismo origen puede no enviar Referer ni Origin — ambos vacíos es válido
$host    = $_SERVER['HTTP_HOST']    ?? '';
$origin  = $_SERVER['HTTP_ORIGIN']  ?? '';
$referer = $_SERVER['HTTP_REFERER'] ?? '';

$fromSameHost = (
    (!empty($origin)  && str_contains($origin,  $host)) ||
    (!empty($referer) && str_contains($referer, $host)) ||
    (empty($origin)   && empty($referer))
);

if (!$fromSameHost) {
    http_response_code(403);
    echo json_encode(['error' => 'Acceso no autorizado']);
    exit;
}

// ── Leer y validar el body JSON ──
$body = file_get_contents('php://input');
$data = json_decode($body, true);

if (empty($data['messages']) || !is_array($data['messages'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Faltan los mensajes']);
    exit;
}

if (count($data['messages']) > 50) {
    http_response_code(400);
    echo json_encode(['error' => 'Demasiados mensajes en el historial']);
    exit;
}

// ── Modelo: whitelist para evitar modelos arbitrarios ──
$allowedModels = [
    'llama-3.3-70b-versatile',
    'llama-3.1-8b-instant',
    'meta-llama/llama-4-scout-17b-16e-instruct',
    'qwen/qwen3-32b',
];
$requestedModel = $data['model'] ?? GROQ_MODEL;
$model = in_array($requestedModel, $allowedModels) ? $requestedModel : GROQ_MODEL;

// ── Armar el payload para Groq ──
$payload = json_encode([
    'model'      => $model,
    'messages'   => $data['messages'],
    'max_tokens' => MAX_TOKENS,
]);

// ── Llamar a la API de Groq con cURL ──
$ch = curl_init(GROQ_URL);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $payload,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . GROQ_API_KEY,
    ],
    CURLOPT_TIMEOUT        => 30,
]);

$response  = curl_exec($ch);
$httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    http_response_code(502);
    echo json_encode(['error' => 'Error de conexión con Groq: ' . $curlError]);
    exit;
}

http_response_code($httpCode);
echo $response;