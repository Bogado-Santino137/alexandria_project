<?php
/**
 * SIDEBAR - Menú lateral izquierdo
 * ================================
 * Usa sistema de rutas dinámico
 */

// Cargar configuración si no está cargada
if (!defined('WEB_ROOT')) {
    require_once __DIR__ . '/../config.php';
}
?>
    <!-- Sidebar Lateral Izquierdo -->
    <aside>
        <ul class="dropdown1">
        <!-- Summus Pontifex: Los PHPesitos -->
        <li class="dropdown__list">
            <input type="checkbox" class="dropdown__check" id="menu-php-principal">
            <label for="menu-php-principal" class="dropdown__link">
                <img src="<?php echo img('php.svg'); ?>" class="dropdown__icon">
                <span class="dropdown__span">PHP</span>
                <img src="<?php echo img('down.svg'); ?>" class="dropdown__arrow">
            </label>
            <div class="dropdown__content">
                <ul class="dropdown__sub">
                    
                    <!-- Urbino: PHP -->
                    <li class="dropdown__list dropdown__list--level2">
                        <input type="checkbox" class="dropdown__check" id="menu-php">
                        <label for="menu-php" class="dropdown__link">
                            <img src="<?php echo img('php.svg'); ?>" class="dropdown__icon">
                            <span class="dropdown__span">PHP</span>
                            <img src="<?php echo img('down.svg'); ?>" class="dropdown__arrow">
                        </label>
                        <div class="dropdown__content">
                            <ul class="dropdown__sub">
                                <li class="dropdown__li"><a href="<?php echo asset('tutorial_php/01_variables.php'); ?>" class="dropdown__anchor"> Variables PHP</a></li>
                                <li class="dropdown__li"><a href="<?php echo asset('tutorial_php/02_strings.php'); ?>" class="dropdown__anchor"> Strings PHP</a></li>
                        </div>
                    </li>

                    <!-- Urbino: 1... -->
                    <li class="dropdown__list dropdown__list--level2">
                        <input type="checkbox" class="dropdown__check" id="menu-1...">
                        <label for="menu-1..." class="dropdown__link">
                            <img src="<?php echo img('php.svg'); ?>" class="dropdown__icon">
                            <span class="dropdown__span">...</span>
                            <img src="<?php echo img('down.svg'); ?>" class="dropdown__arrow">
                        </label>
                        <div class="dropdown__content">
                            <ul class="dropdown__sub">
                                <li class="dropdown__li"><a href="<?php echo asset('php_funciones/e1.php'); ?>" class="dropdown__anchor">...</a></li>
                            </ul>
                        </div>
                    </li>
                    
                </ul>
            </div>
        </li>

        <!-- HTML -->
        <li class="dropdown__list">
            <input type="checkbox" class="dropdown__check" id="menu-html">
            <label for="menu-html" class="dropdown__link">
                <img src="<?php echo img('html.svg'); ?>" class="dropdown__icon">
                <span class="dropdown__span">HTML</span>
                <img src="<?php echo img('down.svg'); ?>" class="dropdown__arrow">
            </label>
            <div class="dropdown__content">
                <ul class="dropdown__sub">
                    <li class="dropdown__li"><a href="<?php echo asset('tutorial_html/01_basico.php'); ?>" class="dropdown__anchor">HTML Básico</a></li>
                </ul>
            </div>
        </li>

        <!-- JAVASCRIPT -->
        <li class="dropdown__list">
            <input type="checkbox" class="dropdown__check" id="menu-js">
            <label for="menu-js" class="dropdown__link">
                <img src="<?php echo img('js.svg'); ?>" class="dropdown__icon">
                <span class="dropdown__span">JavaScript</span>
                <img src="<?php echo img('down.svg'); ?>" class="dropdown__arrow">
            </label>
            <div class="dropdown__content">
                <ul class="dropdown__sub">
                    <li class="dropdown__li"><a href="<?php echo asset('tutorial_js/01_variables.php'); ?>" class="dropdown__anchor"> JavaScript Variables </a></li>
                </ul>
            </div>
        </li>

        <!-- MySQL -->
        <li class="dropdown__list">
            <input type="checkbox" class="dropdown__check" id="menu-mysql">
            <label for="menu-mysql" class="dropdown__link">
                <img src="<?php echo img('mysql.svg'); ?>" class="dropdown__icon">
                <span class="dropdown__span">MySQL</span>
                <img src="<?php echo img('down.svg'); ?>" class="dropdown__arrow">
            </label>
            <div class="dropdown__content">
                <ul class="dropdown__sub">
                    <li class="dropdown__li"><a href="<?php echo asset('tutorial_mysql/01_basico.php'); ?>" class="dropdown__anchor"> MySQL Básico </a></li>
                </ul>
            </div>
        </li>

        <!-- Python -->
        <li class="dropdown__list">
            <input type="checkbox" class="dropdown__check" id="menu-py">
            <label for="menu-py" class="dropdown__link">
                <img src="<?php echo img('python.svg'); ?>" class="dropdown__icon">
                <span class="dropdown__span">Python</span>
                <img src="<?php echo img('down.svg'); ?>" class="dropdown__arrow">
            </label>
            <div class="dropdown__content">
                <ul class="dropdown__sub">
                    <li class="dropdown__li"><a href="<?php echo asset('tutorial_python/01_variables.php'); ?>" class="dropdown__anchor">Variables Python</a></li>
                </ul>
            </div>
        </li>

        <!-- CSS -->
        <li class="dropdown__list">
            <input type="checkbox" class="dropdown__check" id="menu-css">
            <label for="menu-css" class="dropdown__link">
                <img src="<?php echo img('css.svg'); ?>" class="dropdown__icon">
                <span class="dropdown__span"> CSS </span>
                <img src="<?php echo img('down.svg'); ?>" class="dropdown__arrow">
            </label>
            <div class="dropdown__content">
                <ul class="dropdown__sub">
                    <li class="dropdown__li"><a href="<?php echo asset('tutorial_css/01_selectores.php'); ?>" class="dropdown__anchor">Selectores CSS</a></li>
                    <li class="dropdown__li"><a href="<?php echo asset('tutorial_css/02_colores.php'); ?>" class="dropdown__anchor">Colores CSS</a></li>
                </ul>
            </div>
        </li>
        </ul>
    </aside>