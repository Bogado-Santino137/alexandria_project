<?php
/**
 * FOOTER - Pie del sitio
 * =======================
 * @version 2.4
 */

// Cargar configuración si no está cargada
if (!defined('WEB_ROOT')) {
    require_once __DIR__ . '/../config.php';
}
?>

<!-- Scripts del Sistema -->
<!-- 1. Dependencias (orden importa) -->
<script src="<?php echo js('routes.js'); ?>"></script>
<script src="<?php echo js('notifications.js'); ?>"></script>

<!-- 2. Buscador y botones Try It -->
<script src="<?php echo js('search.js'); ?>"></script>

<!-- 3. Prism.js para syntax highlighting -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/line-numbers/prism-line-numbers.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-markup-templating.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-php.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-javascript.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-css.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-python.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-sql.min.js"></script>

<!-- 4. Chatbot IA -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/marked/9.1.6/marked.min.js"></script>
<script src="<?php echo js('chatbot.js'); ?>"></script>

<!-- FOOTER -->
<footer class="site-footer">

        <!-- Columnas -->
        <div class="site-footer__grid">

            <!-- PHP -->
            <div>
                <h4 class="site-footer__heading">PHP</h4>
                <ul class="site-footer__list">
                    <li><a href="<?php echo asset('tutorial_php/01_variables.php'); ?>" class="site-footer__link">Variables PHP</a></li>
                    <li><a href="<?php echo asset('tutorial_php/02_strings.php'); ?>"   class="site-footer__link">Strings PHP</a></li>
                </ul>
            </div>

            <!-- JavaScript -->
            <div>
                <h4 class="site-footer__heading">JavaScript</h4>
                <ul class="site-footer__list">
                    <li><a href="<?php echo asset('tutorial_js/01_variables.php'); ?>" class="site-footer__link">Variables JS</a></li>
                </ul>
            </div>

            <!-- Otros -->
            <div>
                <h4 class="site-footer__heading">Otros</h4>
                <ul class="site-footer__list">
                    <li><a href="<?php echo asset('tutorial_html/01_basico.php'); ?>"      class="site-footer__link">HTML Básico</a></li>
                    <li><a href="<?php echo asset('tutorial_css/01_selectores.php'); ?>"   class="site-footer__link">Selectores CSS</a></li>
                    <li><a href="<?php echo asset('tutorial_css/02_colores.php'); ?>"      class="site-footer__link">Colores CSS</a></li>
                    <li><a href="<?php echo asset('tutorial_python/01_variables.php'); ?>" class="site-footer__link">Variables Python</a></li>
                    <li><a href="<?php echo asset('tutorial_mysql/01_basico.php'); ?>"     class="site-footer__link">MySQL Básico</a></li>
                </ul>
            </div>

        </div>

        <!-- Barra inferior -->
        <div class="site-footer__bottom">
            <p class="site-footer__dots">. . . . . . . . . . . .</p>
            <p class="site-footer__copy">&copy; <?php echo date('Y'); ?> &mdash; Revisar</p>
        </div>

</footer>

<!-- Overlay sidebar mobile -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- Script hamburguesa -->
<!-- Scripts del sistema -->
<script src="<?php echo js('ui.js'); ?>"></script>

</body>
</html>