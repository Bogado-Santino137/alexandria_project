<?php
/**
 * HEADER - Cabecera del sitio
 * ============================
 * @version 3.1 - CHATBOT GROQ (estilo editor)
 */

if (!defined('WEB_ROOT')) {
    require_once __DIR__ . '/../config.php';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle : 'MENU'; ?></title>

    <link rel="stylesheet" href="<?php echo css('styles.css'); ?>"/>
    <link rel="stylesheet" href="<?php echo css('layout.css'); ?>"/>
    <link rel="stylesheet" href="<?php echo css('notifications.css'); ?>"/>
    <link rel="stylesheet" href="<?php echo css('presentation.css'); ?>"/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/line-numbers/prism-line-numbers.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/plugins/toolbar/prism-toolbar.min.css">

</head>
<body>

<header>
    <div class="nav">
        <ul class="ul__a1">

            <!-- HAMBURGUESA (solo mobile) -->
            <li class="dropdown__list">
                <button class="hamburger" id="btnHamburger" aria-label="Menú">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
            </li>

            <!-- INICIO -->
            <li class="dropdown__list">
                <a href="<?php echo asset('index.php'); ?>" class="dropdown__link" title="Inicio">
                    <svg class="nav__icon nav__icon--home" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M8 0L0 6V8H1V15H4V10H7V15H15V8H16V6L14 4.5V1H11V2.25L8 0ZM9 10H12V13H9V10Z" fill="currentColor"/>
                    </svg>
                </a>
            </li>

            <!-- COMPARTIR -->
            <!--li class="dropdown__list">
                <button class="dropdown__link nav__btn--share" id="btnShare" title="Compartir página">
                    <svg class="nav__icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="18" cy="5" r="3"/>
                        <circle cx="6" cy="12" r="3"/>
                        <circle cx="18" cy="19" r="3"/>
                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
                        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                    </svg>
                </button>
            </li-->

            <!-- BUSCADOR -->
            <li class="dropdown__list">
                <div class="container">
                    <div class="search-input-box">
                        <input type="text" id="KS2" name="v1" class="aji" placeholder="Buscar..." autocomplete="off" />
                        <a href="#" class="lupita" id="btn-buscar">
                            <img src="<?php echo img('busq.svg'); ?>" class="dropdown__icon--2">
                        </a>
                        <ul class="container-suggestions"></ul>
                    </div>
                </div>
            </li>

            <!-- BOTÓN CHAT IA -->
            <li class="dropdown__list">
                <div class="nav__container__5">

                    <!-- ABRIR: ícono ia.svg -->
                    <a href="#menu" class="nav__menu">
                        <img src="<?php echo img('ia.svg'); ?>"
                             class="nav__icon"
                             style="filter:invert(1) opacity(.75);"
                             alt="Chat IA">
                        <span class="dropdown__span">CHAT IA</span>
                    </a>

                    <!-- CERRAR: X roja (distinto al de abrir) -->
                    <a href="#" class="nav__menu nav__menu--second" id="chatCloseBtn">
                        <svg xmlns="http://www.w3.org/2000/svg"
                             viewBox="0 0 24 24" fill="none"
                             stroke="#ef4444" stroke-width="2.5"
                             stroke-linecap="round" stroke-linejoin="round"
                             class="nav__icon" style="width:20px;height:20px;">
                            <line x1="18" y1="6"  x2="6"  y2="18"></line>
                            <line x1="6"  y1="6"  x2="18" y2="18"></line>
                        </svg>
                        <span class="dropdown__span" style="color:#ef4444;">CERRAR</span>
                    </a>

                    <!-- PANEL LATERAL — CHATBOT -->
                    <ul class="dropdown" id="menu">
                        <li>
                            <div class="chatbot-wrapper">

                                <!-- Toolbar tipo code-viewer -->
                                <div class="chat-toolbar-header">
                                    <div class="chat-lang-badge">
                                        <img src="<?php echo img('ia.svg'); ?>" alt="IA">
                                        ASISTENTE IA
                                    </div>
                                    <select id="chatModelSelect" class="chat-model-select" title="Elegir modelo">
                                        <option value="llama-3.3-70b-versatile">Llama 3.3 70B — Recomendado</option>
                                        <option value="llama-3.1-8b-instant">Llama 3.1 8B — Más rápido</option>
                                        <option value="meta-llama/llama-4-scout-17b-16e-instruct">Llama 4 Scout 17B — Alternativo</option>
                                        <option value="qwen/qwen3-32b">Qwen 3 32B — Experimental</option>
                                    </select>
                                    <button class="btn-action" id="chatClearBtn" title="Limpiar conversación">
                                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                  d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                                        </svg>
                                    </button>
                                </div>

                                <!-- Contexto archivo actual -->
                                <?php

                                // URL RELATIVA
                                // PHP_SELF: "/mic/6p/mysql/01_basico.php"
                                // WEB_ROOT: "/mic/6p"
                                // resultado: "mysql/01_basico.php"
                                $currentFile = ltrim(
                                    str_replace(WEB_ROOT, '', $_SERVER['PHP_SELF']),
                                    '/'
                                );
                                $currentFileBase = basename($currentFile);
                                $isIndexPage     = in_array($currentFileBase, ['index.php', 'menu.php']);

                                $pageTitles = [
                                    // PHP
                                    'tutorial_php/01_variables.php'         => 'Variables PHP',
                                    'tutorial_php/02_strings.php'           => 'Strings PHP',
                                    
                                    // HTML
                                    'tutorial_html/01_basico.php'           => 'HTML Básico',

                                    // JS
                                    'tutorial_js/01_variables.php'           => 'Variables JavaScript',

                                    // MySQL
                                    'tutorial_mysql/01_basico.php'          => 'MySQL Básico',

                                    // Python
                                    'tutorial_python/01_variables.php'      => 'Variables Python',

                                    // CSS
                                    'tutorial_css/01_selectores.php'        => 'Selectores CSS',
                                    'tutorial_css/02_colores.php'           => 'Colores CSS',
                                ];

                                // Buscar por ruta relativa; si no está, mostrar solo el nombre del archivo
                                $pageLabel = $pageTitles[$currentFile] ?? $currentFileBase;
                                ?>
                                <?php if (!$isIndexPage): ?>
                                <div class="chat-context-bar">
                                    <span>Viendo:</span>
                                    <span class="chat-context-file"><?php echo htmlspecialchars($pageLabel); ?></span>
                                </div>
                                <?php endif; ?>

                                <!-- Mensajes -->
                                <div class="chat-messages" id="chatMessages">
                                    <div class="chat-welcome">
                                        <img src="<?php echo img('ia.svg'); ?>" alt="IA">
                                        <p>
                                            Preguntale al asistente sobre el código,<br>
                                            conceptos de PHP, HTML, JS o MySQL.
                                        </p>
                                    </div>
                                </div>

                                <!-- Input -->
                                <div class="chat-input-area">
                                    <textarea id="chatInput" placeholder="Preguntá algo..." rows="1"></textarea>
                                    <button class="chat-send-btn" id="chatSendBtn" title="Enviar (Enter)">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                             stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                            <line x1="22" y1="2" x2="11" y2="13"></line>
                                            <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                                        </svg>
                                    </button>
                                </div>

                            </div><!-- /chatbot-wrapper -->
                        </li>
                    </ul>

                </div>
            </li>

        </ul>
    </div>
</header>

<!-- Variables del servidor para chatbot.js -->
<script>
window.CHATBOT = {
    proxyUrl:    '<?php echo asset('includes/chat_proxy.php'); ?>',
    currentFile: <?php echo $isIndexPage ? 'null' : json_encode($pageLabel); ?>,
    iaSvg:       '<?php echo img('ia.svg'); ?>'
};
</script>